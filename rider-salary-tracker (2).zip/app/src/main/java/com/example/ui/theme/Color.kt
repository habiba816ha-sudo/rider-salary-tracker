package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Modern Professional Deep Blue Primary Theme
val DeepBluePrimary = Color(0xFF1D4ED8)      // Modern Deep Blue Primary
val DeepBlueDark = Color(0xFF0F172A)         // Dark Navy
val DeepBlueMedium = Color(0xFF1E3A8A)       // Medium Navy
val DeepBlueLight = Color(0xFFDBEAFE)        // Soft Blue Container
val DeepBlueContainer = Color(0xFFEFF6FF)    // Subtle Blue Shade for Cards / Secondary Elements

// Semantic Accents
val SuccessGreen = Color(0xFF16A34A)         // Small success/income green accent
val WarningOrange = Color(0xFFEA580C)        // Orange for warnings/returns
val ErrorRed = Color(0xFFDC2626)             // Red for errors

val GoldHighlight = Color(0xFFD97706)        // Gold/amber highlight
val GoldContainer = Color(0xFFFFFBEB)

// Backgrounds & Surfaces (White / Light Gray)
val BackgroundLight = Color(0xFFF8FAFC)      // Clean light gray background
val SurfaceLight = Color(0xFFFFFFFF)         // White surface
val SurfaceVariantLight = Color(0xFFF1F5F9)  // Subtle blue-gray shade

val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)

// Text Colors (Dark navy/black for primary text)
val TextPrimaryDark = Color(0xFF0F172A)      // Dark Navy / Black primary text
val TextSecondaryDark = Color(0xFF475569)    // Slate 600 secondary text
val TextPrimaryLight = Color(0xFFF8FAFC)     // Light text
val TextSecondaryLight = Color(0xFF94A3B8)   // Secondary light text

// Legacy compatibility aliases mapping to Deep Blue Theme
val EmeraldPrimary = DeepBluePrimary
val EmeraldDark = DeepBlueDark
val EmeraldLight = DeepBlueLight
val EmeraldContainer = DeepBlueContainer

val PathaoAccentRed = ErrorRed
val PathaoRedLight = Color(0xFFFEE2E2)

