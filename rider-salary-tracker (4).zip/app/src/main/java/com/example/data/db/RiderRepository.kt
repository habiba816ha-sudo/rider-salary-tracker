package com.example.data.db

import com.example.data.engine.CalculationEngine
import com.example.data.model.DailyRecord
import com.example.data.model.MonthlySummary
import com.example.data.model.RiderType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class RiderRepository(
    private val dao: DailyRecordDao,
    private val prefs: RiderPreferences
) {

    val allRecords: Flow<List<DailyRecord>> = dao.getAllRecords()
    val riderTypeFlow: StateFlow<RiderType> = prefs.riderTypeFlow

    fun getRecordsForMonth(year: Int, month: Int): Flow<List<DailyRecord>> {
        return dao.getRecordsForMonth(year, month)
    }

    suspend fun getRecordByDate(dateString: String): DailyRecord? {
        return dao.getRecordByDate(dateString)
    }

    suspend fun getRecordById(id: Long): DailyRecord? {
        return dao.getRecordById(id)
    }

    suspend fun cleanupInvalidRecords() {
        dao.deleteInvalidRecords()
    }

    suspend fun saveDailyEntry(
        id: Long = 0,
        dateString: String,
        year: Int,
        month: Int,
        day: Int,
        delivery: Int,
        returnCount: Int,
        holdCount: Int,
        riderType: RiderType = prefs.getRiderType(),
        note: String = ""
    ): Long {
        val cleanDate = dateString.trim()
        if (cleanDate.isBlank()) {
            throw IllegalArgumentException("তারিখ নির্বাচন করুন")
        }

        val target = CalculationEngine.calculateTarget(delivery, returnCount, holdCount)
        val percentage = CalculationEngine.calculatePercentage(delivery, target)
        val commissionRate = CalculationEngine.calculateCommissionRate(delivery, riderType)
        val eligibleIncome = CalculationEngine.calculateEligibleIncome(delivery, commissionRate)
        val oilBill = CalculationEngine.calculateOilBill(delivery, riderType)
        val dailyTotal = CalculationEngine.calculateDailyTotal(eligibleIncome, oilBill)

        val existingRecord = dao.getRecordByDate(cleanDate)
        val targetId = if (id > 0) id else (existingRecord?.id ?: 0L)

        val record = DailyRecord(
            id = targetId,
            dateString = cleanDate,
            year = year,
            month = month,
            day = day,
            riderType = riderType.name,
            delivery = delivery,
            returnCount = returnCount,
            holdCount = holdCount,
            target = target,
            percentage = percentage,
            commissionRate = commissionRate,
            eligibleIncome = eligibleIncome,
            oilBill = oilBill,
            dailyTotal = dailyTotal,
            note = note,
            timestamp = System.currentTimeMillis()
        )

        return dao.insertOrUpdateRecord(record)
    }

    suspend fun deleteRecord(id: Long) {
        dao.deleteRecordById(id)
    }

    suspend fun deleteAll() {
        dao.deleteAllRecords()
    }

    fun setRiderType(type: RiderType) {
        prefs.setRiderType(type)
    }

    fun getRiderType(): RiderType {
        return prefs.getRiderType()
    }

    fun calculateMonthlySummary(year: Int, month: Int, records: List<DailyRecord>): MonthlySummary {
        return CalculationEngine.calculateMonthlySummary(year, month, records)
    }

    suspend fun exportToJson(records: List<DailyRecord>? = null): String {
        val listToExport = if (!records.isNullOrEmpty()) records else dao.getAllRecordsList()
        val rootObj = JSONObject().apply {
            put("backupVersion", 1)
            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            put("createdAt", sdf.format(Date()))
            val jsonArray = JSONArray()
            listToExport.forEach { r ->
                val obj = JSONObject().apply {
                    put("id", r.id)
                    put("dateString", r.dateString)
                    put("year", r.year)
                    put("month", r.month)
                    put("day", r.day)
                    put("riderType", r.riderType)
                    put("delivery", r.delivery)
                    put("returnCount", r.returnCount)
                    put("holdCount", r.holdCount)
                    put("target", r.target)
                    put("percentage", r.percentage)
                    put("commissionRate", r.commissionRate)
                    put("eligibleIncome", r.eligibleIncome)
                    put("oilBill", r.oilBill)
                    put("dailyTotal", r.dailyTotal)
                    put("note", r.note)
                }
                jsonArray.put(obj)
            }
            put("reports", jsonArray)
        }
        return rootObj.toString(2)
    }

    fun parseAndValidateJson(jsonString: String): Result<List<DailyRecord>> {
        val cleanJson = jsonString.trim()
        if (cleanJson.isBlank()) {
            return Result.failure(IllegalArgumentException("ফাইল বা টেক্সট খালি (File/text is empty)"))
        }
        return try {
            val jsonArray: JSONArray = if (cleanJson.startsWith("{")) {
                val rootObj = JSONObject(cleanJson)
                when {
                    rootObj.has("reports") -> rootObj.getJSONArray("reports")
                    rootObj.has("dailyReports") -> rootObj.getJSONArray("dailyReports")
                    rootObj.has("records") -> rootObj.getJSONArray("records")
                    rootObj.has("data") -> rootObj.getJSONArray("data")
                    else -> throw IllegalArgumentException("সঠিক ব্যাকআপ ফাইল স্ট্রাকচার পাওয়া যায়নি ('reports' কী অনুপস্থিত)")
                }
            } else if (cleanJson.startsWith("[")) {
                JSONArray(cleanJson)
            } else {
                return Result.failure(IllegalArgumentException("অবৈধ JSON ব্যাকআপ ফরম্যাট"))
            }

            val recordsList = mutableListOf<DailyRecord>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.optJSONObject(i) ?: continue
                val dateStr = obj.optString("dateString", "")

                val id = obj.optLong("id", 0L)
                val year = obj.optInt("year", 2026)
                val month = obj.optInt("month", 8)
                val day = obj.optInt("day", 1)
                val riderTypeStr = obj.optString("riderType", "INSIDE")
                val delivery = obj.optInt("delivery", 0)
                val returnCount = obj.optInt("returnCount", 0)
                val holdCount = obj.optInt("holdCount", 0)

                val riderType = RiderType.fromString(riderTypeStr)
                val target = if (obj.has("target")) obj.optInt("target") else CalculationEngine.calculateTarget(delivery, returnCount, holdCount)
                val percentage = if (obj.has("percentage")) obj.optDouble("percentage") else CalculationEngine.calculatePercentage(delivery, target)
                val commissionRate = if (obj.has("commissionRate")) obj.optInt("commissionRate") else CalculationEngine.calculateCommissionRate(delivery, riderType)
                val eligibleIncome = if (obj.has("eligibleIncome")) obj.optInt("eligibleIncome") else CalculationEngine.calculateEligibleIncome(delivery, commissionRate)
                val oilBill = if (obj.has("oilBill")) obj.optInt("oilBill") else CalculationEngine.calculateOilBill(delivery, riderType)
                val dailyTotal = if (obj.has("dailyTotal")) obj.optInt("dailyTotal") else CalculationEngine.calculateDailyTotal(eligibleIncome, oilBill)
                val note = obj.optString("note", "")

                val record = DailyRecord(
                    id = id,
                    dateString = dateStr,
                    year = year,
                    month = month,
                    day = day,
                    riderType = riderType.name,
                    delivery = delivery,
                    returnCount = returnCount,
                    holdCount = holdCount,
                    target = target,
                    percentage = percentage,
                    commissionRate = commissionRate,
                    eligibleIncome = eligibleIncome,
                    oilBill = oilBill,
                    dailyTotal = dailyTotal,
                    note = note,
                    timestamp = System.currentTimeMillis()
                )
                recordsList.add(record)
            }

            Result.success(recordsList)
        } catch (e: Exception) {
            Result.failure(IllegalArgumentException("JSON পার্স করার সময় ত্রুটি: ${e.localizedMessage}"))
        }
    }

    suspend fun importFromJson(jsonString: String): Int {
        val validation = parseAndValidateJson(jsonString)
        if (validation.isFailure) {
            throw validation.exceptionOrNull() ?: IllegalArgumentException("অবৈধ ব্যাকআপ ফাইল")
        }
        val records = validation.getOrNull() ?: emptyList()
        dao.deleteAllRecords()
        var count = 0
        for (record in records) {
            dao.insertOrUpdateRecord(record)
            count++
        }
        return count
    }
}
