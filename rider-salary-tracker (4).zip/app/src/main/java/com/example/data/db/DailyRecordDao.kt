package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.DailyRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface DailyRecordDao {

    @Query("SELECT * FROM daily_records WHERE dateString IS NOT NULL AND dateString != '' ORDER BY dateString DESC, timestamp DESC")
    fun getAllRecords(): Flow<List<DailyRecord>>

    @Query("SELECT * FROM daily_records ORDER BY dateString DESC, timestamp DESC")
    suspend fun getAllRecordsList(): List<DailyRecord>

    @Query("SELECT * FROM daily_records WHERE year = :year AND month = :month AND dateString IS NOT NULL AND dateString != '' ORDER BY dateString DESC")
    fun getRecordsForMonth(year: Int, month: Int): Flow<List<DailyRecord>>

    @Query("SELECT * FROM daily_records WHERE dateString = :dateString LIMIT 1")
    suspend fun getRecordByDate(dateString: String): DailyRecord?

    @Query("SELECT * FROM daily_records WHERE id = :id LIMIT 1")
    suspend fun getRecordById(id: Long): DailyRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateRecord(record: DailyRecord): Long

    @Query("DELETE FROM daily_records WHERE id = :id")
    suspend fun deleteRecordById(id: Long)

    @Query("DELETE FROM daily_records WHERE dateString IS NULL OR dateString = ''")
    suspend fun deleteInvalidRecords()

    @Query("DELETE FROM daily_records")
    suspend fun deleteAllRecords()
}
