package com.example.data.drive

import android.content.Context
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.UserRecoverableAuthException
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Headers
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GoogleDriveManager {

    val DRIVE_APPDATA_SCOPE = Scope("https://www.googleapis.com/auth/drive.appdata")
    private const val BACKUP_FILE_NAME = "rider_backup.json"

    fun getGoogleSignInClient(context: Context): GoogleSignInClient {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(DRIVE_APPDATA_SCOPE)
            .build()
        return GoogleSignIn.getClient(context, gso)
    }

    fun getSignedInAccount(context: Context): GoogleSignInAccount? {
        val account = GoogleSignIn.getLastSignedInAccount(context)
        return if (account != null && GoogleSignIn.hasPermissions(account, DRIVE_APPDATA_SCOPE)) {
            account
        } else {
            null
        }
    }

    private fun createOkHttpClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    suspend fun uploadBackupToDrive(
        context: Context,
        account: GoogleSignInAccount,
        jsonContent: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val accountObj = account.account
                ?: return@withContext Result.failure(Exception("Google অ্যাকাউন্টের তথ্য পাওয়া যায়নি"))

            val token = try {
                GoogleAuthUtil.getToken(
                    context,
                    accountObj,
                    "oauth2:https://www.googleapis.com/auth/drive.appdata"
                )
            } catch (e: UserRecoverableAuthException) {
                return@withContext Result.failure(Exception("Google Drive এক্সেস পারমিশন প্রয়োজন। অনুগ্রহ করে পুনরায় সাইন ইন করুন।"))
            } catch (e: Exception) {
                return@withContext Result.failure(Exception("OAuth টোকেন সংগ্রহ করতে সমস্যা: ${e.localizedMessage}"))
            }

            val client = createOkHttpClient()

            // 1. Search for existing file in appDataFolder
            val searchUrl = "https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=name%3D%27$BACKUP_FILE_NAME%27+and+trashed%3Dfalse"
            val searchRequest = Request.Builder()
                .url(searchUrl)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            val searchResponse = client.newCall(searchRequest).execute()
            val searchBody = searchResponse.body?.string() ?: ""
            if (!searchResponse.isSuccessful) {
                return@withContext Result.failure(Exception("Google Drive সার্চ ফেইল করেছে (${searchResponse.code}): $searchBody"))
            }

            val filesArray = JSONObject(searchBody).optJSONArray("files")
            val existingFileId = if (filesArray != null && filesArray.length() > 0) {
                filesArray.getJSONObject(0).optString("id")
            } else null

            if (!existingFileId.isNullOrEmpty()) {
                // Update existing file content
                val updateUrl = "https://www.googleapis.com/upload/drive/v3/files/$existingFileId?uploadType=media"
                val mediaBody = jsonContent.toRequestBody("application/json; charset=utf-8".toMediaType())
                val updateRequest = Request.Builder()
                    .url(updateUrl)
                    .addHeader("Authorization", "Bearer $token")
                    .patch(mediaBody)
                    .build()

                val updateResponse = client.newCall(updateRequest).execute()
                val updateResponseBody = updateResponse.body?.string() ?: ""
                if (!updateResponse.isSuccessful) {
                    return@withContext Result.failure(Exception("Google Drive ব্যাকআপ আপডেট ফেইল করেছে (${updateResponse.code}): $updateResponseBody"))
                }
                Result.success("Google Drive-এ ব্যাকআপ সফলভাবে আপডেট করা হয়েছে!")
            } else {
                // Create new file with multipart
                val createUrl = "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart"
                val metadataJson = JSONObject().apply {
                    put("name", BACKUP_FILE_NAME)
                    put("parents", JSONArray().put("appDataFolder"))
                }.toString()

                val multipartBody = MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addPart(
                        Headers.headersOf("Content-Type", "application/json; charset=UTF-8"),
                        metadataJson.toRequestBody("application/json; charset=utf-8".toMediaType())
                    )
                    .addPart(
                        Headers.headersOf("Content-Type", "application/json; charset=UTF-8"),
                        jsonContent.toRequestBody("application/json; charset=utf-8".toMediaType())
                    )
                    .build()

                val createRequest = Request.Builder()
                    .url(createUrl)
                    .addHeader("Authorization", "Bearer $token")
                    .post(multipartBody)
                    .build()

                val createResponse = client.newCall(createRequest).execute()
                val createResponseBody = createResponse.body?.string() ?: ""
                if (!createResponse.isSuccessful) {
                    return@withContext Result.failure(Exception("Google Drive আপলোড ফেইল করেছে (${createResponse.code}): $createResponseBody"))
                }
                Result.success("Google Drive-এ ব্যাকআপ সফলভাবে তৈরি ও আপলোড করা হয়েছে!")
            }
        } catch (e: Exception) {
            Result.failure(Exception("Google Drive আপলোডে ত্রুটি: ${e.localizedMessage}"))
        }
    }

    suspend fun downloadBackupFromDrive(
        context: Context,
        account: GoogleSignInAccount
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val accountObj = account.account
                ?: return@withContext Result.failure(Exception("Google অ্যাকাউন্টের তথ্য পাওয়া যায়নি"))

            val token = try {
                GoogleAuthUtil.getToken(
                    context,
                    accountObj,
                    "oauth2:https://www.googleapis.com/auth/drive.appdata"
                )
            } catch (e: UserRecoverableAuthException) {
                return@withContext Result.failure(Exception("Google Drive এক্সেস পারমিশন প্রয়োজন। অনুগ্রহ করে পুনরায় সাইন ইন করুন।"))
            } catch (e: Exception) {
                return@withContext Result.failure(Exception("OAuth টোকেন সংগ্রহ করতে সমস্যা: ${e.localizedMessage}"))
            }

            val client = createOkHttpClient()

            // 1. Search for existing file
            val searchUrl = "https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=name%3D%27$BACKUP_FILE_NAME%27+and+trashed%3Dfalse"
            val searchRequest = Request.Builder()
                .url(searchUrl)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            val searchResponse = client.newCall(searchRequest).execute()
            val searchBody = searchResponse.body?.string() ?: ""
            if (!searchResponse.isSuccessful) {
                return@withContext Result.failure(Exception("Google Drive সার্চ ফেইল করেছে (${searchResponse.code}): $searchBody"))
            }

            val filesArray = JSONObject(searchBody).optJSONArray("files")
            if (filesArray == null || filesArray.length() == 0) {
                return@withContext Result.failure(Exception("Google Drive-এ কোনো ব্যাকআপ ফাইল পাওয়া যায়নি (No backup found in Google Drive)"))
            }

            val fileId = filesArray.getJSONObject(0).getString("id")

            // 2. Download file media
            val downloadUrl = "https://www.googleapis.com/drive/v3/files/$fileId?alt=media"
            val downloadRequest = Request.Builder()
                .url(downloadUrl)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            val downloadResponse = client.newCall(downloadRequest).execute()
            val downloadBody = downloadResponse.body?.string() ?: ""
            if (!downloadResponse.isSuccessful) {
                return@withContext Result.failure(Exception("Google Drive থেকে ব্যাকআপ ডাউনলোড ফেইল করেছে (${downloadResponse.code}): $downloadBody"))
            }

            Result.success(downloadBody)
        } catch (e: Exception) {
            Result.failure(Exception("Google Drive ডাউনলোডে ত্রুটি: ${e.localizedMessage}"))
        }
    }

    suspend fun getLastBackupInfo(
        context: Context,
        account: GoogleSignInAccount
    ): Result<String?> = withContext(Dispatchers.IO) {
        try {
            val accountObj = account.account ?: return@withContext Result.success(null)
            val token = GoogleAuthUtil.getToken(
                context,
                accountObj,
                "oauth2:https://www.googleapis.com/auth/drive.appdata"
            )
            val client = createOkHttpClient()
            val searchUrl = "https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=name%3D%27$BACKUP_FILE_NAME%27+and+trashed%3Dfalse&fields=files(id,modifiedTime)"
            val searchRequest = Request.Builder()
                .url(searchUrl)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            val searchResponse = client.newCall(searchRequest).execute()
            val searchBody = searchResponse.body?.string() ?: ""
            if (!searchResponse.isSuccessful) {
                return@withContext Result.success(null)
            }

            val filesArray = JSONObject(searchBody).optJSONArray("files")
            if (filesArray != null && filesArray.length() > 0) {
                val modTime = filesArray.getJSONObject(0).optString("modifiedTime", null)
                Result.success(modTime)
            } else {
                Result.success(null)
            }
        } catch (e: Exception) {
            Result.success(null)
        }
    }
}
