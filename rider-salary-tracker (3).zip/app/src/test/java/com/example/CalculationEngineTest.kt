package com.example.data.engine

import com.example.data.model.RiderType
import org.junit.Assert.assertEquals
import org.junit.Test

class CalculationEngineTest {

    @Test
    fun testInsideRiderCase1_Delivery19_Return3_Hold3() {
        val delivery = 19
        val returnCount = 3
        val holdCount = 3
        val riderType = RiderType.INSIDE

        val target = CalculationEngine.calculateTarget(delivery, returnCount, holdCount)
        val percentage = CalculationEngine.calculatePercentage(delivery, target)
        val rate = CalculationEngine.calculateCommissionRate(delivery, riderType)
        val income = CalculationEngine.calculateEligibleIncome(delivery, rate)
        val oilBill = CalculationEngine.calculateOilBill(delivery, riderType)
        val dailyTotal = CalculationEngine.calculateDailyTotal(income, oilBill)

        assertEquals(25, target)
        assertEquals(76.0, percentage, 0.01)
        assertEquals(23, rate)
        assertEquals(437, income)
        assertEquals(100, oilBill)
        assertEquals(537, dailyTotal)
    }

    @Test
    fun testInsideRiderCase2_Delivery20_Return0_Hold0() {
        val delivery = 20
        val returnCount = 0
        val holdCount = 0
        val riderType = RiderType.INSIDE

        val target = CalculationEngine.calculateTarget(delivery, returnCount, holdCount)
        val percentage = CalculationEngine.calculatePercentage(delivery, target)
        val rate = CalculationEngine.calculateCommissionRate(delivery, riderType)
        val income = CalculationEngine.calculateEligibleIncome(delivery, rate)
        val oilBill = CalculationEngine.calculateOilBill(delivery, riderType)
        val dailyTotal = CalculationEngine.calculateDailyTotal(income, oilBill)

        assertEquals(20, target)
        assertEquals(100.0, percentage, 0.01)
        assertEquals(25, rate)
        assertEquals(500, income)
        assertEquals(100, oilBill)
        assertEquals(600, dailyTotal)
    }

    @Test
    fun testOutsideRiderCase1_Delivery19_Return3_Hold3() {
        val delivery = 19
        val returnCount = 3
        val holdCount = 3
        val riderType = RiderType.OUTSIDE

        val target = CalculationEngine.calculateTarget(delivery, returnCount, holdCount)
        val percentage = CalculationEngine.calculatePercentage(delivery, target)
        val rate = CalculationEngine.calculateCommissionRate(delivery, riderType)
        val income = CalculationEngine.calculateEligibleIncome(delivery, rate)
        val oilBill = CalculationEngine.calculateOilBill(delivery, riderType)
        val dailyTotal = CalculationEngine.calculateDailyTotal(income, oilBill)

        assertEquals(25, target)
        assertEquals(76.0, percentage, 0.01)
        assertEquals(30, rate)
        assertEquals(570, income)
        assertEquals(200, oilBill)
        assertEquals(770, dailyTotal)
    }

    @Test
    fun testOutsideRiderCase2_Delivery20_Return0_Hold0() {
        val delivery = 20
        val returnCount = 0
        val holdCount = 0
        val riderType = RiderType.OUTSIDE

        val target = CalculationEngine.calculateTarget(delivery, returnCount, holdCount)
        val percentage = CalculationEngine.calculatePercentage(delivery, target)
        val rate = CalculationEngine.calculateCommissionRate(delivery, riderType)
        val income = CalculationEngine.calculateEligibleIncome(delivery, rate)
        val oilBill = CalculationEngine.calculateOilBill(delivery, riderType)
        val dailyTotal = CalculationEngine.calculateDailyTotal(income, oilBill)

        assertEquals(20, target)
        assertEquals(100.0, percentage, 0.01)
        assertEquals(32, rate)
        assertEquals(640, income)
        assertEquals(200, oilBill)
        assertEquals(840, dailyTotal)
    }

    @Test
    fun testZeroDelivery() {
        val delivery = 0
        val returnCount = 0
        val holdCount = 0
        val riderType = RiderType.INSIDE

        val target = CalculationEngine.calculateTarget(delivery, returnCount, holdCount)
        val percentage = CalculationEngine.calculatePercentage(delivery, target)
        val rate = CalculationEngine.calculateCommissionRate(delivery, riderType)
        val income = CalculationEngine.calculateEligibleIncome(delivery, rate)
        val oilBill = CalculationEngine.calculateOilBill(delivery, riderType)
        val dailyTotal = CalculationEngine.calculateDailyTotal(income, oilBill)

        assertEquals(0, target)
        assertEquals(0.0, percentage, 0.01)
        assertEquals(23, rate)
        assertEquals(0, income)
        assertEquals(0, oilBill)
        assertEquals(0, dailyTotal)
    }
}
