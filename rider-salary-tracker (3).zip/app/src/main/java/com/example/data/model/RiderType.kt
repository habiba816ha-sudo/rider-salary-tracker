package com.example.data.model

enum class RiderType(val displayNameBn: String, val displayNameEn: String) {
    INSIDE("ইনসাইড রাইডার (Inside Rider)", "Inside Rider"),
    OUTSIDE("আউটসাইড রাইডার (Outside Rider)", "Outside Rider");

    companion object {
        fun fromString(value: String): RiderType {
            return try {
                valueOf(value.uppercase())
            } catch (e: Exception) {
                INSIDE
            }
        }
    }
}
