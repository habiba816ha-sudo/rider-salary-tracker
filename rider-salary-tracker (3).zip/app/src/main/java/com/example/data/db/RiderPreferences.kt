package com.example.data.db

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.RiderType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class RiderPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("rider_salary_tracker_prefs", Context.MODE_PRIVATE)

    private val _riderTypeFlow = MutableStateFlow(getRiderType())
    val riderTypeFlow: StateFlow<RiderType> = _riderTypeFlow.asStateFlow()

    fun getRiderType(): RiderType {
        val typeStr = prefs.getString(KEY_RIDER_TYPE, RiderType.INSIDE.name) ?: RiderType.INSIDE.name
        return RiderType.fromString(typeStr)
    }

    fun setRiderType(riderType: RiderType) {
        prefs.edit().putString(KEY_RIDER_TYPE, riderType.name).apply()
        _riderTypeFlow.value = riderType
    }

    companion object {
        private const val KEY_RIDER_TYPE = "key_rider_type"
    }
}
