package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.DailyRecord

@Database(entities = [DailyRecord::class], version = 2, exportSchema = false)
abstract class RiderDatabase : RoomDatabase() {

    abstract fun dailyRecordDao(): DailyRecordDao

    companion object {
        @Volatile
        private var INSTANCE: RiderDatabase? = null

        fun getDatabase(context: Context): RiderDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RiderDatabase::class.java,
                    "rider_salary_tracker.db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
