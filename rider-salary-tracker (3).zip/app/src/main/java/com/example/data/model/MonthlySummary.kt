package com.example.data.model

data class MonthlySummary(
    val year: Int,
    val month: Int,
    val totalRecords: Int = 0,
    val workingDays: Int = 0,
    val totalDelivery: Int = 0,
    val totalReturn: Int = 0,
    val totalHold: Int = 0,
    val totalTarget: Int = 0,
    val avgDelivery: Double = 0.0,
    val avgReturn: Double = 0.0,
    val avgHold: Double = 0.0,
    val overallPercentage: Double = 0.0,
    val totalEligibleIncome: Int = 0,
    val totalOilBill: Int = 0,
    val expectedMonthlyPayment: Int = 0
)
