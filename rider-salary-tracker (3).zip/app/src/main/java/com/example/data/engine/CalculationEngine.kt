package com.example.data.engine

import com.example.data.model.DailyRecord
import com.example.data.model.MonthlySummary
import com.example.data.model.RiderType
import kotlin.math.floor

object CalculationEngine {

    fun calculateTarget(delivery: Int, returnCount: Int, holdCount: Int): Int {
        val safeDelivery = delivery.coerceAtLeast(0)
        val safeReturn = returnCount.coerceAtLeast(0)
        val safeHold = holdCount.coerceAtLeast(0)
        return safeDelivery + safeReturn + safeHold
    }

    fun calculatePercentage(delivery: Int, target: Int): Double {
        val safeDelivery = delivery.coerceAtLeast(0)
        val safeTarget = target.coerceAtLeast(0)
        if (safeTarget == 0) return 0.0
        return (safeDelivery.toDouble() / safeTarget) * 100.0
    }

    fun calculateCommissionRate(delivery: Int, riderType: RiderType): Int {
        val safeDelivery = delivery.coerceAtLeast(0)
        return when (riderType) {
            RiderType.INSIDE -> {
                if (safeDelivery <= 19) {
                    23
                } else {
                    25 + (floor((safeDelivery - 20).toDouble() / 5.0).toInt() * 2)
                }
            }
            RiderType.OUTSIDE -> {
                if (safeDelivery <= 19) {
                    30
                } else {
                    32 + (floor((safeDelivery - 20).toDouble() / 5.0).toInt() * 2)
                }
            }
        }
    }

    fun calculateEligibleIncome(delivery: Int, commissionRate: Int): Int {
        val safeDelivery = delivery.coerceAtLeast(0)
        val safeRate = commissionRate.coerceAtLeast(0)
        return safeDelivery * safeRate
    }

    fun calculateOilBill(delivery: Int, riderType: RiderType): Int {
        val safeDelivery = delivery.coerceAtLeast(0)
        if (safeDelivery == 0) return 0
        return when (riderType) {
            RiderType.INSIDE -> 100
            RiderType.OUTSIDE -> 200
        }
    }

    fun calculateDailyTotal(eligibleIncome: Int, oilBill: Int): Int {
        val safeIncome = eligibleIncome.coerceAtLeast(0)
        val safeOil = oilBill.coerceAtLeast(0)
        return safeIncome + safeOil
    }

    fun calculateMonthlySummary(
        year: Int,
        month: Int,
        records: List<DailyRecord>
    ): MonthlySummary {
        val uniqueRecords = records.distinctBy { it.dateString }
        val totalRecords = uniqueRecords.size
        val workingDays = uniqueRecords.count { it.delivery > 0 }
        
        val totalDelivery = uniqueRecords.sumOf { it.delivery }
        val totalReturn = uniqueRecords.sumOf { it.returnCount }
        val totalHold = uniqueRecords.sumOf { it.holdCount }
        val totalTarget = uniqueRecords.sumOf { it.target }

        val avgDelivery = if (workingDays > 0) totalDelivery.toDouble() / workingDays else 0.0
        val avgReturn = if (workingDays > 0) totalReturn.toDouble() / workingDays else 0.0
        val avgHold = if (workingDays > 0) totalHold.toDouble() / workingDays else 0.0

        val overallPercentage = if (totalTarget > 0) (totalDelivery.toDouble() / totalTarget) * 100.0 else 0.0

        val totalEligibleIncome = uniqueRecords.sumOf { it.eligibleIncome }
        val totalOilBill = uniqueRecords.sumOf { it.oilBill }
        val expectedMonthlyPayment = totalEligibleIncome + totalOilBill

        return MonthlySummary(
            year = year,
            month = month,
            totalRecords = totalRecords,
            workingDays = workingDays,
            totalDelivery = totalDelivery,
            totalReturn = totalReturn,
            totalHold = totalHold,
            totalTarget = totalTarget,
            avgDelivery = avgDelivery,
            avgReturn = avgReturn,
            avgHold = avgHold,
            overallPercentage = overallPercentage,
            totalEligibleIncome = totalEligibleIncome,
            totalOilBill = totalOilBill,
            expectedMonthlyPayment = expectedMonthlyPayment
        )
    }
}
