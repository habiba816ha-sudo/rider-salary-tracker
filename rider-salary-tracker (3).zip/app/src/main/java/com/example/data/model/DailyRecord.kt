package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "daily_records",
    indices = [Index(value = ["dateString"], unique = true)]
)
data class DailyRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dateString: String, // Format: "YYYY-MM-DD" e.g., "2026-08-09"
    val year: Int,
    val month: Int, // 1 - 12
    val day: Int,   // 1 - 31
    val riderType: String, // "INSIDE" or "OUTSIDE"
    val delivery: Int,
    val returnCount: Int,
    val holdCount: Int,
    val target: Int,
    val percentage: Double,
    val commissionRate: Int,
    val eligibleIncome: Int,
    val oilBill: Int,
    val dailyTotal: Int,
    val note: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
