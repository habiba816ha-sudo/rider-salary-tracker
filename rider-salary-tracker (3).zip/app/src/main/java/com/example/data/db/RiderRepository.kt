package com.example.data.db

import com.example.data.engine.CalculationEngine
import com.example.data.model.DailyRecord
import com.example.data.model.MonthlySummary
import com.example.data.model.RiderType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

class RiderRepository(
    private val dao: DailyRecordDao,
    private val prefs: RiderPreferences
) {

    val allRecords: Flow<List<DailyRecord>> = dao.getAllRecords()
    val riderTypeFlow: StateFlow<RiderType> = prefs.riderTypeFlow

    fun getRecordsForMonth(year: Int, month: Int): Flow<List<DailyRecord>> {
        return dao.getRecordsForMonth(year, month)
    }

    suspend fun getRecordByDate(dateString: String): DailyRecord? {
        return dao.getRecordByDate(dateString)
    }

    suspend fun getRecordById(id: Long): DailyRecord? {
        return dao.getRecordById(id)
    }

    suspend fun cleanupInvalidRecords() {
        dao.deleteInvalidRecords()
    }

    suspend fun saveDailyEntry(
        id: Long = 0,
        dateString: String,
        year: Int,
        month: Int,
        day: Int,
        delivery: Int,
        returnCount: Int,
        holdCount: Int,
        riderType: RiderType = prefs.getRiderType(),
        note: String = ""
    ): Long {
        val cleanDate = dateString.trim()
        if (cleanDate.isBlank()) {
            throw IllegalArgumentException("তারিখ নির্বাচন করুন")
        }

        val target = CalculationEngine.calculateTarget(delivery, returnCount, holdCount)
        val percentage = CalculationEngine.calculatePercentage(delivery, target)
        val commissionRate = CalculationEngine.calculateCommissionRate(delivery, riderType)
        val eligibleIncome = CalculationEngine.calculateEligibleIncome(delivery, commissionRate)
        val oilBill = CalculationEngine.calculateOilBill(delivery, riderType)
        val dailyTotal = CalculationEngine.calculateDailyTotal(eligibleIncome, oilBill)

        val existingRecord = dao.getRecordByDate(cleanDate)
        val targetId = if (id > 0) id else (existingRecord?.id ?: 0L)

        val record = DailyRecord(
            id = targetId,
            dateString = cleanDate,
            year = year,
            month = month,
            day = day,
            riderType = riderType.name,
            delivery = delivery,
            returnCount = returnCount,
            holdCount = holdCount,
            target = target,
            percentage = percentage,
            commissionRate = commissionRate,
            eligibleIncome = eligibleIncome,
            oilBill = oilBill,
            dailyTotal = dailyTotal,
            note = note,
            timestamp = System.currentTimeMillis()
        )

        return dao.insertOrUpdateRecord(record)
    }

    suspend fun deleteRecord(id: Long) {
        dao.deleteRecordById(id)
    }

    suspend fun deleteAll() {
        dao.deleteAllRecords()
    }

    fun setRiderType(type: RiderType) {
        prefs.setRiderType(type)
    }

    fun getRiderType(): RiderType {
        return prefs.getRiderType()
    }

    fun calculateMonthlySummary(year: Int, month: Int, records: List<DailyRecord>): MonthlySummary {
        return CalculationEngine.calculateMonthlySummary(year, month, records)
    }

    suspend fun exportToJson(records: List<DailyRecord>): String {
        val jsonArray = JSONArray()
        records.forEach { r ->
            val obj = JSONObject().apply {
                put("id", r.id)
                put("dateString", r.dateString)
                put("year", r.year)
                put("month", r.month)
                put("day", r.day)
                put("riderType", r.riderType)
                put("delivery", r.delivery)
                put("returnCount", r.returnCount)
                put("holdCount", r.holdCount)
                put("target", r.target)
                put("percentage", r.percentage)
                put("commissionRate", r.commissionRate)
                put("eligibleIncome", r.eligibleIncome)
                put("oilBill", r.oilBill)
                put("dailyTotal", r.dailyTotal)
                put("note", r.note)
            }
            jsonArray.put(obj)
        }
        return jsonArray.toString(2)
    }

    suspend fun importFromJson(jsonString: String): Int {
        var count = 0
        try {
            val jsonArray = JSONArray(jsonString)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val dateStr = obj.optString("dateString", "")
                val year = obj.optInt("year", 2026)
                val month = obj.optInt("month", 8)
                val day = obj.optInt("day", 1)
                val delivery = obj.optInt("delivery", 0)
                val returnCount = obj.optInt("returnCount", 0)
                val holdCount = obj.optInt("holdCount", 0)
                val riderTypeStr = obj.optString("riderType", "INSIDE")
                val riderType = RiderType.fromString(riderTypeStr)
                val note = obj.optString("note", "")

                if (dateStr.isNotEmpty()) {
                    saveDailyEntry(
                        id = 0, // Insert as new or updated
                        dateString = dateStr,
                        year = year,
                        month = month,
                        day = day,
                        delivery = delivery,
                        returnCount = returnCount,
                        holdCount = holdCount,
                        riderType = riderType,
                        note = note
                    )
                    count++
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return count
    }
}
