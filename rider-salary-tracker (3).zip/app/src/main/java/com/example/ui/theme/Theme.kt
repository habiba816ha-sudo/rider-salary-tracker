package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = DeepBluePrimary,
    onPrimary = Color.White,
    primaryContainer = DeepBlueDark,
    onPrimaryContainer = DeepBlueLight,
    secondary = ErrorRed,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF7F1D1D),
    onSecondaryContainer = PathaoRedLight,
    tertiary = GoldHighlight,
    onTertiary = Color.Black,
    tertiaryContainer = GoldContainer,
    onTertiaryContainer = GoldHighlight,
    background = BackgroundDark,
    onBackground = TextPrimaryLight,
    surface = SurfaceDark,
    onSurface = TextPrimaryLight,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = TextSecondaryLight
)

private val LightColorScheme = lightColorScheme(
    primary = DeepBluePrimary,
    onPrimary = Color.White,
    primaryContainer = DeepBlueContainer,
    onPrimaryContainer = DeepBlueDark,
    secondary = ErrorRed,
    onSecondary = Color.White,
    secondaryContainer = PathaoRedLight,
    onSecondaryContainer = ErrorRed,
    tertiary = GoldHighlight,
    onTertiary = Color.Black,
    tertiaryContainer = GoldContainer,
    onTertiaryContainer = GoldHighlight,
    background = BackgroundLight,
    onBackground = TextPrimaryDark,
    surface = SurfaceLight,
    onSurface = TextPrimaryDark,
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = TextSecondaryDark
)

@Composable
fun RiderSalaryTrackerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Set false to maintain Pathao brand identity
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
