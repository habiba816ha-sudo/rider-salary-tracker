package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
    val route: String,
    val titleBn: String,
    val titleEn: String,
    val icon: ImageVector
) {
    object Dashboard : Screen("dashboard", "ড্যাশবোর্ড", "Dashboard", Icons.Default.Dashboard)
    object DailyEntry : Screen("daily_entry?date={date}&id={id}", "দৈনিক এন্ট্রি", "Entry", Icons.Default.AddCircle) {
        fun createRoute(date: String? = null, id: Long? = null): String {
            return when {
                date != null && id != null -> "daily_entry?date=$date&id=$id"
                date != null -> "daily_entry?date=$date"
                id != null -> "daily_entry?id=$id"
                else -> "daily_entry"
            }
        }
    }
    object History : Screen("history", "হিস্ট্রি", "History", Icons.Default.History)
    object Summary : Screen("summary", "মাসিক হিসাব", "Summary", Icons.Default.Analytics)
    object Settings : Screen("settings", "সেটিংস", "Settings", Icons.Default.Settings)
}
