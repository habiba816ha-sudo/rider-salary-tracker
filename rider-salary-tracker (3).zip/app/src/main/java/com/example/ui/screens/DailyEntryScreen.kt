package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.CalculationEngine
import com.example.data.model.DailyRecord
import com.example.data.model.RiderType
import com.example.ui.components.AdBannerPlaceholder
import com.example.ui.components.formatCurrency
import com.example.ui.theme.DeepBluePrimary
import com.example.ui.theme.GoldHighlight
import com.example.ui.viewmodel.RiderViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun DailyEntryScreen(
    viewModel: RiderViewModel,
    initialDateString: String? = null,
    editingRecordId: Long? = null,
    onSaved: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentRiderTypePref by viewModel.riderType.collectAsState()
    val allRecords by viewModel.allRecords.collectAsState()

    var dateString by remember { mutableStateOf(initialDateString ?: viewModel.todayDateString) }
    var recordId by remember { mutableStateOf(editingRecordId ?: 0L) }

    var deliveryInput by remember { mutableStateOf("0") }
    var returnInput by remember { mutableStateOf("0") }
    var holdInput by remember { mutableStateOf("0") }
    var selectedRiderType by remember { mutableStateOf(currentRiderTypePref) }
    var noteInput by remember { mutableStateOf("") }

    var showUpdateDialog by remember { mutableStateOf(false) }
    var existingRecordForDate by remember { mutableStateOf<DailyRecord?>(null) }

    // Check if record exists for selected date when editing or prefilling
    LaunchedEffect(dateString, allRecords) {
        if (editingRecordId != null) {
            val recordToEdit = allRecords.find { it.id == editingRecordId }
            if (recordToEdit != null) {
                dateString = recordToEdit.dateString
                recordId = recordToEdit.id
                deliveryInput = recordToEdit.delivery.toString()
                returnInput = recordToEdit.returnCount.toString()
                holdInput = recordToEdit.holdCount.toString()
                selectedRiderType = RiderType.fromString(recordToEdit.riderType)
                noteInput = recordToEdit.note
            }
        } else {
            val existing = allRecords.find { it.dateString == dateString }
            if (existing != null) {
                deliveryInput = existing.delivery.toString()
                returnInput = existing.returnCount.toString()
                holdInput = existing.holdCount.toString()
                selectedRiderType = RiderType.fromString(existing.riderType)
                noteInput = existing.note
            }
        }
    }

    val deliveryVal = deliveryInput.toIntOrNull()?.coerceAtLeast(0) ?: 0
    val returnVal = returnInput.toIntOrNull()?.coerceAtLeast(0) ?: 0
    val holdVal = holdInput.toIntOrNull()?.coerceAtLeast(0) ?: 0

    // Automatic Live Calculations
    val target = CalculationEngine.calculateTarget(deliveryVal, returnVal, holdVal)
    val percentage = CalculationEngine.calculatePercentage(deliveryVal, target)
    val commissionRate = CalculationEngine.calculateCommissionRate(deliveryVal, selectedRiderType)
    val eligibleIncome = CalculationEngine.calculateEligibleIncome(deliveryVal, commissionRate)
    val oilBill = CalculationEngine.calculateOilBill(deliveryVal, selectedRiderType)
    val dailyTotal = CalculationEngine.calculateDailyTotal(eligibleIncome, oilBill)

    val calendar = Calendar.getInstance()
    val datePickerDialog = remember {
        val parts = dateString.split("-")
        val y = parts.getOrNull(0)?.toIntOrNull() ?: calendar.get(Calendar.YEAR)
        val m = (parts.getOrNull(1)?.toIntOrNull() ?: (calendar.get(Calendar.MONTH) + 1)) - 1
        val d = parts.getOrNull(2)?.toIntOrNull() ?: calendar.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(
            context,
            { _, year, monthOfYear, dayOfMonth ->
                val formattedMonth = String.format(Locale.US, "%02d", monthOfYear + 1)
                val formattedDay = String.format(Locale.US, "%02d", dayOfMonth)
                dateString = "$year-$formattedMonth-$formattedDay"
            },
            y, m, d
        )
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("daily_entry_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Screen Header
        Text(
            text = if (recordId > 0) "দৈনিক এন্ট্রি এডিট করুন (Edit Entry)" else "দৈনিক ডাটা এন্ট্রি (Daily Entry)",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground
        )

        // Date Picker Field
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "তারিখ (Date)",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = dateString,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Button(
                    onClick = { datePickerDialog.show() },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.testTag("btn_select_date")
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "তারিখ পরিবর্তন",
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Rider Type Segmented Selection for this record
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "রাইডার টাইপ (Rider Type)",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))

                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = selectedRiderType == RiderType.INSIDE,
                        onClick = { selectedRiderType = RiderType.INSIDE },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                        modifier = Modifier.testTag("segment_inside_rider")
                    ) {
                        Text("ইনসাইড (Inside)")
                    }
                    SegmentedButton(
                        selected = selectedRiderType == RiderType.OUTSIDE,
                        onClick = { selectedRiderType = RiderType.OUTSIDE },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                        modifier = Modifier.testTag("segment_outside_rider")
                    ) {
                        Text("আউটসাইড (Outside)")
                    }
                }
            }
        }

        // Input Fields Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "দৈনিক তথ্য ইনপুট দিন",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )

                // Delivery Field
                OutlinedTextField(
                    value = deliveryInput,
                    onValueChange = { input ->
                        if (input.isEmpty() || input.all { it.isDigit() }) {
                            deliveryInput = input
                        }
                    },
                    label = { Text("ডেলিভারি (Delivery)") },
                    placeholder = { Text("0") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("input_delivery"),
                    shape = RoundedCornerShape(12.dp)
                )

                // Return Field
                OutlinedTextField(
                    value = returnInput,
                    onValueChange = { input ->
                        if (input.isEmpty() || input.all { it.isDigit() }) {
                            returnInput = input
                        }
                    },
                    label = { Text("রিটার্ন (Return)") },
                    placeholder = { Text("0") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("input_return"),
                    shape = RoundedCornerShape(12.dp)
                )

                // Hold Field
                OutlinedTextField(
                    value = holdInput,
                    onValueChange = { input ->
                        if (input.isEmpty() || input.all { it.isDigit() }) {
                            holdInput = input
                        }
                    },
                    label = { Text("হোল্ড (Hold)") },
                    placeholder = { Text("0") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("input_hold"),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }

        // Live Automatic Calculations Preview Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("auto_calculation_preview_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.Calculate,
                        contentDescription = null,
                        tint = DeepBluePrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "স্বয়ংক্রিয় গণনার প্রিভিউ (Live Calculation)",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Breakdown Rows
                CalcRow(labelBn = "টার্গেট (Target = D + R + H)", value = "$target")
                CalcRow(labelBn = "ডেলিভারি % (Delivery Percentage)", value = "${String.format("%.2f", percentage)}%")
                CalcRow(labelBn = "কমিশন রেট (Commission Rate)", value = "৳ $commissionRate /পার্সেল")
                CalcRow(labelBn = "Eligible Income (ডেলিভারি × রেট)", value = "৳ ${formatCurrency(eligibleIncome)}")
                CalcRow(labelBn = "Oil Bill (কোম্পানি পেমেন্ট)", value = "৳ $oilBill", isHighlight = true)

                Divider(modifier = Modifier.padding(vertical = 8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "দৈনিক মোট (Daily Total)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "৳ ${formatCurrency(dailyTotal)}",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = DeepBluePrimary
                        )
                    )
                }
            }
        }

        // Update Confirmation Dialog for Duplicate Date Entry
        if (showUpdateDialog) {
            AlertDialog(
                onDismissRequest = { showUpdateDialog = false },
                title = {
                    Text(
                        text = "এই তারিখের হিসাব আগে থেকেই দেওয়া আছে।",
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Text(
                        text = "এই তারিখের একটি হিসাব আগে থেকেই আছে। আপনি কি আগের হিসাবটি আপডেট করতে চান?",
                        style = MaterialTheme.typography.bodyMedium
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showUpdateDialog = false
                            val targetId = existingRecordForDate?.id ?: recordId
                            viewModel.saveDailyRecord(
                                id = targetId,
                                dateString = dateString.trim(),
                                delivery = deliveryVal,
                                returnCount = returnVal,
                                holdCount = holdVal,
                                riderTypeOverride = selectedRiderType,
                                note = noteInput
                            )
                            onSaved()
                        },
                        modifier = Modifier.testTag("btn_confirm_update")
                    ) {
                        Text(
                            text = "হিসাব আপডেট করুন",
                            fontWeight = FontWeight.Bold,
                            color = DeepBluePrimary
                        )
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showUpdateDialog = false },
                        modifier = Modifier.testTag("btn_cancel_update")
                    ) {
                        Text(text = "বাতিল")
                    }
                }
            )
        }

        // Save Button
        Button(
            onClick = {
                val cleanDate = dateString.trim()
                if (cleanDate.isBlank()) {
                    android.widget.Toast.makeText(context, "তারিখ নির্বাচন করুন", android.widget.Toast.LENGTH_SHORT).show()
                    return@Button
                }

                val existing = allRecords.find { it.dateString == cleanDate }
                if (existing != null && (editingRecordId == null || existing.id != editingRecordId)) {
                    existingRecordForDate = existing
                    showUpdateDialog = true
                } else {
                    viewModel.saveDailyRecord(
                        id = recordId,
                        dateString = cleanDate,
                        delivery = deliveryVal,
                        returnCount = returnVal,
                        holdCount = holdVal,
                        riderTypeOverride = selectedRiderType,
                        note = noteInput
                    )
                    onSaved()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("btn_save_daily_entry"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = DeepBluePrimary)
        ) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (recordId > 0) "হিসাব আপডেট করুন (Update)" else "হিসাব সংরক্ষণ করুন (Save)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        AdBannerPlaceholder()
    }
}

@Composable
private fun CalcRow(
    labelBn: String,
    value: String,
    isHighlight: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = labelBn,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = if (isHighlight) GoldHighlight else MaterialTheme.colorScheme.onSurface
            )
        )
    }
}
