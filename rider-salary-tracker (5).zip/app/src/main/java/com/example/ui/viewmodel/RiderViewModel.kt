package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.db.RiderDatabase
import com.example.data.db.RiderPreferences
import com.example.data.db.RiderRepository
import com.example.data.engine.CalculationEngine
import com.example.data.model.DailyRecord
import com.example.data.model.MonthlySummary
import com.example.data.model.RiderType
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RiderViewModel(
    application: Application,
    private val repository: RiderRepository
) : AndroidViewModel(application) {

    val riderType: StateFlow<RiderType> = repository.riderTypeFlow

    // Initialize to current active salary cycle (26th to 25th)
    private val initialSalaryMonth = CalculationEngine.getCurrentSalaryMonth()
    val selectedYear = MutableStateFlow(initialSalaryMonth.first)
    val selectedMonth = MutableStateFlow(initialSalaryMonth.second)

    private val _uiEvent = MutableSharedFlow<String>()
    val uiEvent: SharedFlow<String> = _uiEvent.asSharedFlow()

    init {
        viewModelScope.launch {
            repository.cleanupInvalidRecords()
        }
    }

    val allRecords: StateFlow<List<DailyRecord>> = repository.allRecords
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    @OptIn(ExperimentalCoroutinesApi::class)
    val currentMonthRecords: StateFlow<List<DailyRecord>> = combine(selectedYear, selectedMonth) { year, month ->
        Pair(year, month)
    }.flatMapLatest { (year, month) ->
        repository.getRecordsForMonth(year, month)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val monthlySummary: StateFlow<MonthlySummary> = combine(
        selectedYear,
        selectedMonth,
        currentMonthRecords
    ) { year, month, records ->
        CalculationEngine.calculateMonthlySummary(year, month, records)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MonthlySummary(initialSalaryMonth.first, initialSalaryMonth.second)
    )

    val todayDateString: String
        get() {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            return sdf.format(Date())
        }

    val todayRecord: StateFlow<DailyRecord?> = allRecords.combine(MutableStateFlow(todayDateString)) { records, todayStr ->
        records.find { it.dateString == todayStr }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    fun setRiderType(type: RiderType) {
        viewModelScope.launch {
            repository.setRiderType(type)
            _uiEvent.emit("রাইডার টাইপ আপডেট করা হয়েছে: ${type.displayNameEn}")
        }
    }

    fun setSelectedMonth(year: Int, month: Int) {
        selectedYear.value = year
        selectedMonth.value = month
    }

    fun saveDailyRecord(
        id: Long = 0,
        dateString: String,
        delivery: Int,
        returnCount: Int,
        holdCount: Int,
        riderTypeOverride: RiderType? = null,
        note: String = ""
    ) {
        viewModelScope.launch {
            try {
                val parts = dateString.split("-")
                val year = if (parts.size >= 3) parts[0].toIntOrNull() ?: selectedYear.value else selectedYear.value
                val month = if (parts.size >= 3) parts[1].toIntOrNull() ?: selectedMonth.value else selectedMonth.value
                val day = if (parts.size >= 3) parts[2].toIntOrNull() ?: 1 else 1

                val activeRiderType = riderTypeOverride ?: riderType.value

                repository.saveDailyEntry(
                    id = id,
                    dateString = dateString,
                    year = year,
                    month = month,
                    day = day,
                    delivery = delivery,
                    returnCount = returnCount,
                    holdCount = holdCount,
                    riderType = activeRiderType,
                    note = note
                )
                _uiEvent.emit("রেকর্ড সংরক্ষণ করা হয়েছে! (Record Saved)")
            } catch (e: Exception) {
                _uiEvent.emit("ত্রুটি: ${e.localizedMessage}")
            }
        }
    }

    fun deleteRecord(id: Long) {
        viewModelScope.launch {
            try {
                repository.deleteRecord(id)
                _uiEvent.emit("রেকর্ড মুছে ফেলা হয়েছে (Record Deleted)")
            } catch (e: Exception) {
                _uiEvent.emit("ত্রুটি: ${e.localizedMessage}")
            }
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            try {
                repository.deleteAll()
                _uiEvent.emit("সকল ডাটা মুছে ফেলা হয়েছে (All Data Cleared)")
            } catch (e: Exception) {
                _uiEvent.emit("ত্রুটি: ${e.localizedMessage}")
            }
        }
    }

    suspend fun getBackupJson(): String {
        return repository.exportToJson(allRecords.value)
    }

    fun validateBackupJson(jsonString: String): Result<List<DailyRecord>> {
        return repository.parseAndValidateJson(jsonString)
    }

    fun restoreBackupJson(
        jsonString: String,
        onSuccess: (Int) -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                val count = repository.importFromJson(jsonString)
                _uiEvent.emit("$count টি রেকর্ড রিস্টোর করা হয়েছে ($count Records Restored)")
                onSuccess(count)
            } catch (e: Exception) {
                val msg = e.localizedMessage ?: "রিস্টোর ব্যর্থ হয়েছে"
                _uiEvent.emit("ত্রুটি: $msg")
                onError(msg)
            }
        }
    }

    class Factory(private val application: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val database = RiderDatabase.getDatabase(application)
            val prefs = RiderPreferences(application)
            val repository = RiderRepository(database.dailyRecordDao(), prefs)
            return RiderViewModel(application, repository) as T
        }
    }
}
