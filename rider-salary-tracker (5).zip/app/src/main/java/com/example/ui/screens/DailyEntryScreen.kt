package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.CalculationEngine
import com.example.data.model.DailyRecord
import com.example.data.model.RiderType
import com.example.ui.components.formatCurrency
import com.example.ui.theme.DeepBluePrimary
import com.example.ui.theme.GoldHighlight
import com.example.ui.viewmodel.RiderViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private fun sanitizeDate(input: String?, defaultDate: String): String {
    if (input.isNullOrBlank()) return defaultDate
    if (input.contains("{") || input.contains("}")) return defaultDate
    val parts = input.trim().split("-")
    if (parts.size != 3) return defaultDate
    val y = parts[0].toIntOrNull() ?: return defaultDate
    val m = parts[1].toIntOrNull() ?: return defaultDate
    val d = parts[2].toIntOrNull() ?: return defaultDate
    if (y < 2000 || y > 2100 || m !in 1..12 || d !in 1..31) return defaultDate
    return String.format(Locale.US, "%04d-%02d-%02d", y, m, d)
}

private fun formatBanglaDate(dateStr: String): String {
    return try {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val date = sdf.parse(dateStr) ?: Date()
        val bengaliSdf = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("bn", "BD"))
        bengaliSdf.format(date)
    } catch (e: Exception) {
        dateStr
    }
}

@Composable
fun DailyEntryScreen(
    viewModel: RiderViewModel,
    initialDateString: String? = null,
    editingRecordId: Long? = null,
    onSaved: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentRiderTypePref by viewModel.riderType.collectAsState()
    val allRecords by viewModel.allRecords.collectAsState()

    // Always guarantee a valid sanitized date (defaulting to today if null or contains placeholder like "{date}")
    val safeInitialDate = remember(initialDateString, viewModel.todayDateString) {
        sanitizeDate(initialDateString, viewModel.todayDateString)
    }

    var dateString by remember(safeInitialDate) { mutableStateOf(safeInitialDate) }
    var recordId by remember { mutableStateOf(editingRecordId ?: 0L) }

    var deliveryInput by remember { mutableStateOf("0") }
    var returnInput by remember { mutableStateOf("0") }
    var holdInput by remember { mutableStateOf("0") }
    var selectedRiderType by remember { mutableStateOf(currentRiderTypePref) }
    var noteInput by remember { mutableStateOf("") }

    var showUpdateDialog by remember { mutableStateOf(false) }
    var existingRecordForDate by remember { mutableStateOf<DailyRecord?>(null) }

    // Check if record exists for selected date when editing or prefilling
    LaunchedEffect(dateString, allRecords, editingRecordId) {
        val cleanDate = sanitizeDate(dateString, viewModel.todayDateString)
        if (cleanDate != dateString) {
            dateString = cleanDate
        }

        if (editingRecordId != null && editingRecordId > 0L) {
            val recordToEdit = allRecords.find { it.id == editingRecordId }
            if (recordToEdit != null) {
                dateString = sanitizeDate(recordToEdit.dateString, viewModel.todayDateString)
                recordId = recordToEdit.id
                deliveryInput = recordToEdit.delivery.toString()
                returnInput = recordToEdit.returnCount.toString()
                holdInput = recordToEdit.holdCount.toString()
                selectedRiderType = RiderType.fromString(recordToEdit.riderType)
                noteInput = recordToEdit.note
            }
        } else {
            val existing = allRecords.find { it.dateString == cleanDate }
            if (existing != null) {
                recordId = existing.id
                deliveryInput = existing.delivery.toString()
                returnInput = existing.returnCount.toString()
                holdInput = existing.holdCount.toString()
                selectedRiderType = RiderType.fromString(existing.riderType)
                noteInput = existing.note
            } else {
                recordId = 0L
                deliveryInput = "0"
                returnInput = "0"
                holdInput = "0"
                selectedRiderType = currentRiderTypePref
                noteInput = ""
            }
        }
    }

    val deliveryVal = deliveryInput.toIntOrNull()?.coerceAtLeast(0) ?: 0
    val returnVal = returnInput.toIntOrNull()?.coerceAtLeast(0) ?: 0
    val holdVal = holdInput.toIntOrNull()?.coerceAtLeast(0) ?: 0

    // Automatic Live Calculations
    val target = CalculationEngine.calculateTarget(deliveryVal, returnVal, holdVal)
    val percentage = CalculationEngine.calculatePercentage(deliveryVal, target)
    val commissionRate = CalculationEngine.calculateCommissionRate(deliveryVal, selectedRiderType)
    val eligibleIncome = CalculationEngine.calculateEligibleIncome(deliveryVal, commissionRate)
    val oilBill = CalculationEngine.calculateOilBill(deliveryVal, selectedRiderType)
    val dailyTotal = CalculationEngine.calculateDailyTotal(eligibleIncome, oilBill)

    val validDate = sanitizeDate(dateString, viewModel.todayDateString)

    // Android Native DatePickerDialog Setup
    val datePickerDialog = remember(context, validDate) {
        val calendar = Calendar.getInstance()
        val parts = validDate.split("-")
        val y = parts.getOrNull(0)?.toIntOrNull() ?: calendar.get(Calendar.YEAR)
        val m = (parts.getOrNull(1)?.toIntOrNull() ?: (calendar.get(Calendar.MONTH) + 1)) - 1
        val d = parts.getOrNull(2)?.toIntOrNull() ?: calendar.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(
            context,
            { _, year, monthOfYear, dayOfMonth ->
                val formattedMonth = String.format(Locale.US, "%02d", monthOfYear + 1)
                val formattedDay = String.format(Locale.US, "%02d", dayOfMonth)
                dateString = "$year-$formattedMonth-$formattedDay"
            },
            y, m, d
        )
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("daily_entry_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Screen Header
        Text(
            text = if (recordId > 0) "দৈনিক এন্ট্রি এডিট করুন (Edit Entry)" else "দৈনিক ডাটা এন্ট্রি (Daily Entry)",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground
        )

        // Date Picker Field
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "তারিখ (Date)",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = validDate,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.testTag("entry_date_display")
                    )
                    Text(
                        text = formatBanglaDate(validDate),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Button(
                    onClick = { datePickerDialog.show() },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.testTag("btn_select_date")
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "তারিখ পরিবর্তন",
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Rider Type Segmented Selection for this record
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "রাইডার টাইপ (Rider Type)",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))

                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = selectedRiderType == RiderType.INSIDE,
                        onClick = { selectedRiderType = RiderType.INSIDE },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                        modifier = Modifier.testTag("segment_inside_rider")
                    ) {
                        Text("ইনসাইড (Inside)")
                    }
                    SegmentedButton(
                        selected = selectedRiderType == RiderType.OUTSIDE,
                        onClick = { selectedRiderType = RiderType.OUTSIDE },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                        modifier = Modifier.testTag("segment_outside_rider")
                    ) {
                        Text("আউটসাইড (Outside)")
                    }
                }
            }
        }

        // Input Fields (Delivery, Return, Hold)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "দৈনিক তথ্য ইনপুট দিন",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )

                OutlinedTextField(
                    value = deliveryInput,
                    onValueChange = { deliveryInput = it.filter { ch -> ch.isDigit() } },
                    label = { Text("ডেলিভারি (Delivery)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_delivery"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = returnInput,
                    onValueChange = { returnInput = it.filter { ch -> ch.isDigit() } },
                    label = { Text("রিটার্ন (Return)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_return"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = holdInput,
                    onValueChange = { holdInput = it.filter { ch -> ch.isDigit() } },
                    label = { Text("হোল্ড (Hold)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_hold"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = noteInput,
                    onValueChange = { noteInput = it },
                    label = { Text("নোট / মন্তব্য (ঐচ্ছিক)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_note"),
                    shape = RoundedCornerShape(12.dp),
                    maxLines = 2
                )
            }
        }

        // Live Auto Calculations Box
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Calculate,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "স্বয়ংক্রিয় গণনার প্রিভিউ (Live Calculation)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Divider(modifier = Modifier.padding(vertical = 4.dp))

                CalcRow(labelBn = "টার্গেট (Target = D + R + H)", value = "$target")
                CalcRow(labelBn = "ডেলিভারি % (Delivery Percentage)", value = String.format(Locale.US, "%.2f%%", percentage))
                CalcRow(
                    labelBn = "কমিশন রেট (Commission Rate)",
                    value = if (commissionRate > 0) "৳ $commissionRate /পার্সেল" else "৳ 0"
                )
                CalcRow(
                    labelBn = "Eligible Income (ডেলিভারি × রেট)",
                    value = formatCurrency(eligibleIncome)
                )
                CalcRow(
                    labelBn = "Oil Bill (কোম্পানি পেমেন্ট)",
                    value = formatCurrency(oilBill),
                    isHighlight = oilBill > 0
                )

                Divider(modifier = Modifier.padding(vertical = 4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "আজকের মোট সম্ভাব্য আয়",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = formatCurrency(dailyTotal),
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                        color = GoldHighlight,
                        modifier = Modifier.testTag("preview_daily_total")
                    )
                }
            }
        }

        // Overwrite Warning Dialog
        if (showUpdateDialog && existingRecordForDate != null) {
            AlertDialog(
                onDismissRequest = { showUpdateDialog = false },
                title = { Text("তারিখের হিসাব ইতিমধ্যে বিদ্যমান") },
                text = {
                    Text("এই তারিখে (${validDate}) ইতিমধ্যে একটি এন্ট্রি রয়েছে। আপনি কি এটি ওভাররাইট করতে চান?")
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showUpdateDialog = false
                            val cleanDate = sanitizeDate(dateString, viewModel.todayDateString)
                            viewModel.saveDailyRecord(
                                id = existingRecordForDate?.id ?: 0,
                                dateString = cleanDate,
                                delivery = deliveryVal,
                                returnCount = returnVal,
                                holdCount = holdVal,
                                riderTypeOverride = selectedRiderType,
                                note = noteInput
                            )
                            onSaved()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("হ্যাঁ, ওভাররাইট করুন")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showUpdateDialog = false }) {
                        Text("বাতিল")
                    }
                }
            )
        }

        // Save Button
        Button(
            onClick = {
                val cleanDate = sanitizeDate(dateString, viewModel.todayDateString)
                val existing = allRecords.find { it.dateString == cleanDate }
                if (existing != null && (editingRecordId == null || existing.id != editingRecordId)) {
                    existingRecordForDate = existing
                    showUpdateDialog = true
                } else {
                    viewModel.saveDailyRecord(
                        id = recordId,
                        dateString = cleanDate,
                        delivery = deliveryVal,
                        returnCount = returnVal,
                        holdCount = holdVal,
                        riderTypeOverride = selectedRiderType,
                        note = noteInput
                    )
                    onSaved()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("btn_save_daily_entry"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = DeepBluePrimary)
        ) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (recordId > 0) "হিসাব আপডেট করুন (Update)" else "হিসাব সংরক্ষণ করুন (Save)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }
    }
}

@Composable
private fun CalcRow(
    labelBn: String,
    value: String,
    isHighlight: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = labelBn,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = if (isHighlight) GoldHighlight else MaterialTheme.colorScheme.onSurface
            )
        )
    }
}
