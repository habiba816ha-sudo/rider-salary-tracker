package com.example.ui.components

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

private const val TAG = "AdsterraBanner"

/**
 * Isolated, safe Adsterra banner component for native Android Jetpack Compose.
 * Uses the existing Adsterra script tag from the project:
 * https://pl30895482.effectivecpmnetwork.com/12/26/29/1226298055f7ded9fba1a61103984aaf.js
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AdsterraBanner(
    modifier: Modifier = Modifier
) {
    var hasError by remember { mutableStateOf(false) }

    if (hasError) {
        // Graceful error state: collapse container without breaking UI or crashing
        return
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .padding(horizontal = 4.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp),
            factory = { context ->
                Log.d(TAG, "Initializing Adsterra WebView container")
                WebView(context).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    setBackgroundColor(0) // Transparent background
                    
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        databaseEnabled = true
                        loadWithOverviewMode = true
                        useWideViewPort = true
                        mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                        cacheMode = WebSettings.LOAD_DEFAULT
                        
                        // Set mobile user agent for clean Adsterra mobile banner rendering
                        val defaultAgent = userAgentString ?: ""
                        if (!defaultAgent.contains("Mobile")) {
                            userAgentString = "$defaultAgent Mobile"
                        }
                    }

                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                            super.onPageStarted(view, url, favicon)
                            Log.d(TAG, "Adsterra ad loading started: $url")
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            Log.d(TAG, "Adsterra ad page finished loading: $url")
                        }

                        override fun onReceivedError(
                            view: WebView?,
                            request: WebResourceRequest?,
                            error: WebResourceError?
                        ) {
                            super.onReceivedError(view, request, error)
                            if (request?.isForMainFrame == true) {
                                Log.e(TAG, "Adsterra WebView error: ${error?.description} (code: ${error?.errorCode})")
                                hasError = true
                            }
                        }

                        override fun onReceivedHttpError(
                            view: WebView?,
                            request: WebResourceRequest?,
                            errorResponse: WebResourceResponse?
                        ) {
                            super.onReceivedHttpError(view, request, errorResponse)
                            if (request?.isForMainFrame == true) {
                                Log.e(TAG, "Adsterra HTTP error: status ${errorResponse?.statusCode}")
                            }
                        }

                        override fun shouldOverrideUrlLoading(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): Boolean {
                            val url = request?.url?.toString()
                            if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                                // Ad click: open destination link safely in external browser
                                Log.d(TAG, "Ad click detected, opening external browser: $url")
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                    context.startActivity(intent)
                                    return true
                                } catch (e: Exception) {
                                    Log.e(TAG, "Failed to open external ad link: ${e.message}")
                                }
                            }
                            return false
                        }
                    }

                    webChromeClient = object : WebChromeClient() {
                        override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                            Log.d(
                                TAG,
                                "Adsterra JS Console: [${consoleMessage?.messageLevel()}] ${consoleMessage?.message()} -- line ${consoleMessage?.lineNumber()}"
                            )
                            return true
                        }
                    }

                    // HTML payload containing exact project Adsterra script tag
                    val htmlContent = """
                        <!DOCTYPE html>
                        <html>
                        <head>
                            <meta charset="utf-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
                            <style>
                                * { margin: 0; padding: 0; box-sizing: border-box; }
                                html, body {
                                    width: 100%;
                                    height: 100%;
                                    overflow: hidden;
                                    background: transparent;
                                    display: flex;
                                    justify-content: center;
                                    align-items: center;
                                }
                                #ad-container {
                                    width: 100%;
                                    height: 100%;
                                    display: flex;
                                    justify-content: center;
                                    align-items: center;
                                    overflow: hidden;
                                }
                            </style>
                        </head>
                        <body>
                            <div id="ad-container">
                                <script type="text/javascript" src="https://pl30895482.effectivecpmnetwork.com/12/26/29/1226298055f7ded9fba1a61103984aaf.js"></script>
                            </div>
                        </body>
                        </html>
                    """.trimIndent()

                    loadDataWithBaseURL(
                        "https://effectivecpmnetwork.com",
                        htmlContent,
                        "text/html",
                        "UTF-8",
                        null
                    )
                }
            },
            onRelease = { webView ->
                Log.d(TAG, "Releasing and destroying Adsterra WebView on lifecycle disposal")
                try {
                    webView.stopLoading()
                    webView.loadUrl("about:blank")
                    webView.onPause()
                    webView.removeAllViews()
                    webView.destroy()
                } catch (e: Exception) {
                    Log.e(TAG, "Error destroying WebView: ${e.message}")
                }
            }
        )
    }
}
