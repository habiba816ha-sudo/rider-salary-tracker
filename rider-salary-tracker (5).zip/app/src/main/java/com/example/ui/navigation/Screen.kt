package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ElectricBike
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
    val route: String,
    val titleBn: String,
    val titleEn: String,
    val icon: ImageVector
) {
    object Splash : Screen("splash", "ওয়েলকাম", "Splash", Icons.Default.ElectricBike)
    object Dashboard : Screen("dashboard", "ড্যাশবোর্ড", "Dashboard", Icons.Default.Dashboard)
    object DailyEntry : Screen("daily_entry", "দৈনিক এন্ট্রি", "Entry", Icons.Default.AddCircle) {
        const val ROUTE_WITH_ARGS = "daily_entry?date={date}&id={id}"
        fun createRoute(date: String? = null, id: Long? = null): String {
            val validDate = if (date.isNullOrBlank() || date.contains("{") || !date.contains("-")) null else date.trim()
            val validId = if (id != null && id > 0L) id else null
            return when {
                validDate != null && validId != null -> "daily_entry?date=$validDate&id=$validId"
                validDate != null -> "daily_entry?date=$validDate"
                validId != null -> "daily_entry?id=$validId"
                else -> "daily_entry"
            }
        }
    }
    object History : Screen("history", "হিস্ট্রি", "History", Icons.Default.History)
    object Summary : Screen("summary", "মাসিক হিসাব", "Summary", Icons.Default.Analytics)
    object Settings : Screen("settings", "সেটিংস", "Settings", Icons.Default.Settings)
}
