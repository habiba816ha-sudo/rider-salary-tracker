package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.CalculationEngine
import com.example.data.model.DailyRecord
import com.example.data.model.MonthlySummary
import com.example.data.model.RiderType
import com.example.ui.components.ExpectedPaymentCard
import com.example.ui.components.MetricCard
import com.example.ui.components.MonthPickerHeader
import com.example.ui.components.formatCurrency
import com.example.ui.theme.DeepBluePrimary
import com.example.ui.theme.GoldHighlight
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningOrange
import com.example.ui.viewmodel.RiderViewModel

@Composable
fun DashboardScreen(
    viewModel: RiderViewModel,
    onNavigateToEntry: (dateString: String?) -> Unit,
    onNavigateToHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val riderType by viewModel.riderType.collectAsState()
    val selectedYear by viewModel.selectedYear.collectAsState()
    val selectedMonth by viewModel.selectedMonth.collectAsState()
    val monthlySummary by viewModel.monthlySummary.collectAsState()
    val todayRecord by viewModel.todayRecord.collectAsState()

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("dashboard_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header Row: Title & Rider Type Selector Badge
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DeepBluePrimary,
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.TwoWheeler,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Pathao Salary Tracker",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "রাইডার স্যালারি ট্র্যাকার",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Quick Rider Type Toggle Chip
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = if (riderType == RiderType.INSIDE) DeepBluePrimary.copy(alpha = 0.15f) else WarningOrange.copy(alpha = 0.15f),
                modifier = Modifier.testTag("rider_type_toggle_chip")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (riderType == RiderType.INSIDE) "ইনসাইড রাইডার" else "আউটসাইড রাইডার",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = if (riderType == RiderType.INSIDE) DeepBluePrimary else WarningOrange
                    )
                }
            }
        }

        // Month Selector Header
        MonthPickerHeader(
            selectedYear = selectedYear,
            selectedMonth = selectedMonth,
            onMonthSelected = { y, m -> viewModel.setSelectedMonth(y, m) }
        )

        // Prominent Expected Monthly Payment Hero Card
        ExpectedPaymentCard(summary = monthlySummary)

        // Today's Status Section Card
        TodayStatusCard(
            todayRecord = todayRecord,
            todayDateStr = viewModel.todayDateString,
            riderType = riderType,
            onAddEditToday = { onNavigateToEntry(viewModel.todayDateString) }
        )

        // Monthly Breakdown Header
        Text(
            text = "মাসিক পারফরম্যান্স ড্যাশবোর্ড (${CalculationEngine.getSalaryMonthNameBn(monthlySummary.month)} ${monthlySummary.year})",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground
        )

        // Monthly Summary Metrics Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                titleBn = "মোট ডেলিভারি",
                titleEn = "Total Delivery",
                value = "${monthlySummary.totalDelivery}",
                icon = Icons.Default.CheckCircle,
                iconColor = SuccessGreen,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                titleBn = "মোট টার্গেট",
                titleEn = "Total Target",
                value = "${monthlySummary.totalTarget}",
                icon = Icons.Default.Receipt,
                iconColor = DeepBluePrimary,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                titleBn = "মোট রিটার্ন",
                titleEn = "Total Return",
                value = "${monthlySummary.totalReturn}",
                icon = Icons.Default.MoneyOff,
                iconColor = WarningOrange,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                titleBn = "মোট হোল্ড",
                titleEn = "Total Hold",
                value = "${monthlySummary.totalHold}",
                icon = Icons.Default.PauseCircle,
                iconColor = GoldHighlight,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                titleBn = "গড় ডেলিভারি",
                titleEn = "Avg Delivery / Day",
                value = String.format("%.1f", monthlySummary.avgDelivery),
                icon = Icons.Default.LocalShipping,
                iconColor = DeepBluePrimary,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                titleBn = "ডেলিভারি %",
                titleEn = "Overall Success",
                value = String.format("%.1f", monthlySummary.overallPercentage),
                unit = "%",
                icon = Icons.Default.Analytics,
                iconColor = SuccessGreen,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                titleBn = "মোট আয়",
                titleEn = "Eligible Income",
                value = "৳ ${formatCurrency(monthlySummary.totalEligibleIncome)}",
                icon = Icons.Default.Payments,
                iconColor = SuccessGreen,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                titleBn = "মোট Oil Bill",
                titleEn = "Total Oil Allowance",
                value = "৳ ${formatCurrency(monthlySummary.totalOilBill)}",
                icon = Icons.Default.LocalGasStation,
                iconColor = GoldHighlight,
                modifier = Modifier.weight(1f)
            )
        }

        // View Full History Button
        OutlinedButton(
            onClick = onNavigateToHistory,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("btn_view_full_history"),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("সকল হিস্ট্রি দেখুন (View Full History)")
        }
    }
}

@Composable
private fun TodayStatusCard(
    todayRecord: DailyRecord?,
    todayDateStr: String,
    riderType: RiderType,
    onAddEditToday: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("today_status_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = null,
                        tint = DeepBluePrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "আজকের হিসাব (Today: $todayDateStr)",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (todayRecord != null) {
                    Button(
                        onClick = onAddEditToday,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DeepBluePrimary),
                        modifier = Modifier.testTag("btn_edit_today")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("এডিট করুন")
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (todayRecord != null) {
                // Today's entry stats summary
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "ডেলিভারি: ${todayRecord.delivery} | রিটার্ন: ${todayRecord.returnCount} | হোল্ড: ${todayRecord.holdCount}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Text(
                            text = "টার্গেট: ${todayRecord.target} (${String.format("%.1f", todayRecord.percentage)}%)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "৳ ${formatCurrency(todayRecord.dailyTotal)}",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = DeepBluePrimary
                            )
                        )
                        Text(
                            text = "রেট: ৳${todayRecord.commissionRate} | তেল: ৳${todayRecord.oilBill}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "আজকের কোনো হিসাব দেওয়া হয়নি",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}
