package com.example.ui.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DailyEntryScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.MonthlySummaryScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.viewmodel.RiderViewModel

@Composable
fun AppNavigation(
    viewModel: RiderViewModel,
    modifier: Modifier = Modifier
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.uiEvent.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    val isSplashScreen = currentRoute == Screen.Splash.route

    Scaffold(
        modifier = modifier,
        bottomBar = {
            if (!isSplashScreen) {
                RiderBottomBar(
                    currentRoute = currentRoute,
                    onNavigate = { screen ->
                        val destinationRoute = if (screen == Screen.DailyEntry) {
                            Screen.DailyEntry.createRoute()
                        } else {
                            screen.route
                        }
                        navController.navigate(destinationRoute) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Splash.route,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            composable(Screen.Splash.route) {
                SplashScreen(
                    onSplashFinished = {
                        navController.navigate(Screen.Dashboard.route) {
                            popUpTo(Screen.Splash.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(Screen.Dashboard.route) {
                DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToEntry = { dateStr ->
                        navController.navigate(Screen.DailyEntry.createRoute(date = dateStr))
                    },
                    onNavigateToHistory = {
                        navController.navigate(Screen.History.route)
                    }
                )
            }

            composable(
                route = Screen.DailyEntry.ROUTE_WITH_ARGS,
                arguments = listOf(
                    navArgument("date") {
                        type = NavType.StringType
                        nullable = true
                        defaultValue = null
                    },
                    navArgument("id") {
                        type = NavType.LongType
                        defaultValue = 0L
                    }
                )
            ) { backStackEntry ->
                val rawDate = backStackEntry.arguments?.getString("date")
                val dateArg = if (rawDate.isNullOrBlank() || rawDate.contains("{") || !rawDate.contains("-")) {
                    null
                } else {
                    rawDate.trim()
                }
                val idArg = backStackEntry.arguments?.getLong("id")?.takeIf { it > 0L }

                DailyEntryScreen(
                    viewModel = viewModel,
                    initialDateString = dateArg,
                    editingRecordId = idArg,
                    onSaved = {
                        navController.navigate(Screen.Dashboard.route) {
                            popUpTo(Screen.Dashboard.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(Screen.History.route) {
                HistoryScreen(
                    viewModel = viewModel,
                    onEditRecord = { record ->
                        navController.navigate(Screen.DailyEntry.createRoute(date = record.dateString, id = record.id))
                    },
                    onAddNew = {
                        navController.navigate(Screen.DailyEntry.createRoute())
                    }
                )
            }

            composable(Screen.Summary.route) {
                MonthlySummaryScreen(viewModel = viewModel)
            }

            composable(Screen.Settings.route) {
                SettingsScreen(viewModel = viewModel)
            }
        }
    }
}
