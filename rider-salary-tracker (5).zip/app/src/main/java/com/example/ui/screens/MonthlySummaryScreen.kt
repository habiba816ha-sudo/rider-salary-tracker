package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AdsterraBanner
import com.example.ui.components.ExpectedPaymentCard
import com.example.ui.components.MonthPickerHeader
import com.example.ui.components.formatCurrency
import com.example.ui.theme.DeepBluePrimary
import com.example.ui.theme.GoldHighlight
import com.example.ui.viewmodel.RiderViewModel

@Composable
fun MonthlySummaryScreen(
    viewModel: RiderViewModel,
    modifier: Modifier = Modifier
) {
    val selectedYear by viewModel.selectedYear.collectAsState()
    val selectedMonth by viewModel.selectedMonth.collectAsState()
    val summary by viewModel.monthlySummary.collectAsState()

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("monthly_summary_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Screen Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Analytics,
                contentDescription = null,
                tint = DeepBluePrimary,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "মাসিক হিসাব বিবরণী (Monthly Summary)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "অটোমেটিক গাণিতিক রিপোর্ট (২৬ তারিখ – ২৫ তারিখ সাইকেল)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Month Picker
        MonthPickerHeader(
            selectedYear = selectedYear,
            selectedMonth = selectedMonth,
            onMonthSelected = { y, m -> viewModel.setSelectedMonth(y, m) }
        )

        // Calculation Period Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("calculation_period_card"),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.DateRange,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Calculation Period (স্যালারি সময়সীমা):",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = summary.calculationPeriod,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // Hero Card: Expected Monthly Payment
        ExpectedPaymentCard(summary = summary)

        // Work Days & Delivery Averages Breakdown Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "কাজের দিন ও গড়ের হিসাব",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(12.dp))

                SummaryRow(labelBn = "মোট কাজের দিন (Working Days)", value = "${summary.workingDays} দিন")
                SummaryRow(labelBn = "মোট ডেলিভারি (Total Delivery)", value = "${summary.totalDelivery} টি")
                SummaryRow(labelBn = "মোট টার্গেট (Total Target)", value = "${summary.totalTarget} টি")
                SummaryRow(labelBn = "মোট রিটার্ন (Total Return)", value = "${summary.totalReturn} টি")
                SummaryRow(labelBn = "মোট হোল্ড (Total Hold)", value = "${summary.totalHold} টি")

                Divider(modifier = Modifier.padding(vertical = 8.dp))

                SummaryRow(labelBn = "দৈনিক গড় ডেলিভারি (Average Delivery)", value = String.format("%.2f", summary.avgDelivery))
                SummaryRow(labelBn = "দৈনিক গড় রিটার্ন (Average Return)", value = String.format("%.2f", summary.avgReturn))
                SummaryRow(labelBn = "দৈনিক গড় হোল্ড (Average Hold)", value = String.format("%.2f", summary.avgHold))
                SummaryRow(labelBn = "সার্বিক সাফল্য (Overall Percentage)", value = "${String.format("%.2f", summary.overallPercentage)}%")
            }
        }

        // Financial Earnings Breakdown Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "মাসিক আয় ও তেলের বিল",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(12.dp))

                SummaryRow(
                    labelBn = "মোট অর্জিত আয় (Total Eligible Income)",
                    value = "৳ ${formatCurrency(summary.totalEligibleIncome)}"
                )
                SummaryRow(
                    labelBn = "মোট তেলের বিল (Total Oil Bill)",
                    value = "৳ ${formatCurrency(summary.totalOilBill)}",
                    isHighlight = true
                )

                Divider(modifier = Modifier.padding(vertical = 8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "সম্ভাব্য মোট মাসিক পেমেন্ট",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "৳ ${formatCurrency(summary.expectedMonthlyPayment)}",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = DeepBluePrimary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Adsterra Banner
            AdsterraBanner(
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
private fun SummaryRow(
    labelBn: String,
    value: String,
    isHighlight: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = labelBn,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = if (isHighlight) GoldHighlight else MaterialTheme.colorScheme.onSurface
            )
        )
    }
}
