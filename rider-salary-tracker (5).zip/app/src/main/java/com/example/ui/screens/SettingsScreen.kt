package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AdsClick
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.drive.GoogleDriveManager
import com.example.data.model.RiderType
import com.example.ui.components.AdsterraBanner
import com.example.ui.theme.DeepBluePrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.GoldHighlight
import com.example.ui.theme.WarningOrange
import com.example.ui.viewmodel.RiderViewModel
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: RiderViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val coroutineScope = rememberCoroutineScope()

    val currentRiderType by viewModel.riderType.collectAsState()

    var showClearDataDialog by remember { mutableStateOf(false) }
    var showBackupDialog by remember { mutableStateOf(false) }
    var showRestoreDialog by remember { mutableStateOf(false) }
    var backupJsonText by remember { mutableStateOf("") }
    var importJsonText by remember { mutableStateOf("") }

    var pendingRestoreContent by remember { mutableStateOf<String?>(null) }
    var pendingRestoreRecordCount by remember { mutableStateOf(0) }
    var showConfirmRestoreDialog by remember { mutableStateOf(false) }

    var googleAccount by remember { mutableStateOf(GoogleDriveManager.getSignedInAccount(context)) }
    var isDriveLoading by remember { mutableStateOf(false) }
    var driveLastBackupTime by remember { mutableStateOf<String?>(null) }

    var pendingDriveRestoreContent by remember { mutableStateOf<String?>(null) }
    var pendingDriveRecordCount by remember { mutableStateOf(0) }
    var showConfirmDriveRestoreDialog by remember { mutableStateOf(false) }

    LaunchedEffect(googleAccount) {
        googleAccount?.let { acc ->
            coroutineScope.launch {
                val res = GoogleDriveManager.getLastBackupInfo(context, acc)
                if (res.isSuccess) {
                    driveLastBackupTime = res.getOrNull()
                }
            }
        }
    }

    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)
            if (account != null && GoogleSignIn.hasPermissions(account, GoogleDriveManager.DRIVE_APPDATA_SCOPE)) {
                googleAccount = account
                Toast.makeText(context, "Google Drive-এ সাইন ইন সফল হয়েছে!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Google Drive পারমিশন প্রদান করা হয়নি", Toast.LENGTH_LONG).show()
            }
        } catch (e: ApiException) {
            Toast.makeText(context, "সাইন ইন ব্যর্থ হয়েছে (কোড: ${e.statusCode}): ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    val createDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        uri?.let {
            coroutineScope.launch {
                try {
                    val json = viewModel.getBackupJson()
                    context.contentResolver.openOutputStream(it)?.use { outputStream ->
                        outputStream.write(json.toByteArray())
                    }
                    Toast.makeText(context, "ব্যাকআপ ফাইল সফলভাবে সেভ করা হয়েছে!", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "ত্রুটি: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            coroutineScope.launch {
                try {
                    val content = context.contentResolver.openInputStream(it)?.use { inputStream ->
                        inputStream.bufferedReader().use { reader -> reader.readText() }
                    } ?: ""

                    val validation = viewModel.validateBackupJson(content)
                    if (validation.isSuccess) {
                        val records = validation.getOrThrow()
                        pendingRestoreContent = content
                        pendingRestoreRecordCount = records.size
                        showConfirmRestoreDialog = true
                    } else {
                        val errMsg = validation.exceptionOrNull()?.message ?: "অবৈধ ব্যাকআপ ফাইল"
                        Toast.makeText(context, "রিস্টোর ব্যর্থ: $errMsg", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(context, "ফাইল পড়তে সমস্যা হয়েছে: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("settings_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = null,
                tint = DeepBluePrimary,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "সেটিংস ও রেট টেবিল (Settings)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "রাইডার ধরন ও কমিশন নিয়মনীতি",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Active Rider Type Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "বর্তমান রাইডার ক্যাটাগরি (Active Rider Category)",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "রাইডার টাইপ পরিবর্তন করলে নতুন এন্ট্রিতে নতুন রেট প্রযোজ্য হবে। আগের দিনের হিস্ট্রি পরিবর্তন হবে না।",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = currentRiderType == RiderType.INSIDE,
                        onClick = { viewModel.setRiderType(RiderType.INSIDE) },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                        modifier = Modifier.testTag("setting_rider_inside")
                    ) {
                        Text("ইনসাইড রাইডার (Inside)")
                    }
                    SegmentedButton(
                        selected = currentRiderType == RiderType.OUTSIDE,
                        onClick = { viewModel.setRiderType(RiderType.OUTSIDE) },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                        modifier = Modifier.testTag("setting_rider_outside")
                    ) {
                        Text("আউটসাইড রাইডার (Outside)")
                    }
                }
            }
        }

        // Commission Rules Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = DeepBluePrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "কমিশন ও তেলের বিল নিয়মমালা",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Inside Rider Rules
                Text(
                    text = "১. ইনসাইড রাইডার (INSIDE RIDER):",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = DeepBluePrimary
                    )
                )
                Text(
                    text = "• ১–১৯ পার্সেল: ২৩ ৳ /পার্সেল\n• ২০–২৪ পার্সেল: ২৫ ৳ /পার্সেল\n• ২৫–২৯ পার্সেল: ২৭ ৳ /পার্সেল\n• ৩০–৩৪ পার্সেল: ২৯ ৳ /পার্সেল\n• পরবর্তী প্রতি ৫টি পার্সেলে ২ ৳ করে বৃদ্ধি পায়\n• Oil Bill: ১০০ ৳ (১ বা তার বেশি ডেলিভারি হলে)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 8.dp, top = 4.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Outside Rider Rules
                Text(
                    text = "২. আউটসাইড রাইডার (OUTSIDE RIDER):",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = WarningOrange
                    )
                )
                Text(
                    text = "• ১–১৯ পার্সেল: ৩০ ৳ /পার্সেল\n• ২০–২৪ পার্সেল: ৩২ ৳ /পার্সেল\n• ২৫–২৯ পার্সেল: ৩৪ ৳ /পার্সেল\n• ৩০–৩৪ পার্সেল: ৩৬ ৳ /পার্সেল\n• পরবর্তী প্রতি ৫টি পার্সেলে ২ ৳ করে বৃদ্ধি পায়\n• Oil Bill: ২০০ ৳ (১ বা তার বেশি ডেলিভারি হলে)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 8.dp, top = 4.dp)
                )
            }
        }

        // Google Drive Cloud Backup Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Cloud,
                            contentDescription = null,
                            tint = DeepBluePrimary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Google Drive ক্লাউড ব্যাকআপ",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    if (isDriveLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp,
                            color = DeepBluePrimary
                        )
                    }
                }

                if (googleAccount == null) {
                    Text(
                        text = "আপনার Google Account দিয়ে সাইন ইন করে Google Drive-এর App Data ফোল্ডারে নিরাপদ ও স্বয়ংক্রিয় ক্লাউড ব্যাকআপ রাখুন।",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = {
                            val signInIntent = GoogleDriveManager.getGoogleSignInClient(context).signInIntent
                            googleSignInLauncher.launch(signInIntent)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_google_drive_signin"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DeepBluePrimary)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Google Accounts-এ সাইন ইন করুন")
                    }
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = null,
                            tint = DeepBluePrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = googleAccount?.displayName ?: "Google User",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = googleAccount?.email ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(
                            onClick = {
                                GoogleDriveManager.getGoogleSignInClient(context).signOut().addOnCompleteListener {
                                    googleAccount = null
                                    driveLastBackupTime = null
                                    Toast.makeText(context, "সাইন আউট সফল হয়েছে। আপনার লোকাল ডাটা সুরক্ষিত রয়েছে।", Toast.LENGTH_SHORT).show()
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Logout,
                                contentDescription = "Sign Out",
                                tint = ErrorRed,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    if (driveLastBackupTime != null) {
                        Text(
                            text = "সর্বশেষ ব্যাকআপ সময়: $driveLastBackupTime",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                val acc = googleAccount ?: return@Button
                                isDriveLoading = true
                                coroutineScope.launch {
                                    val backupJson = viewModel.getBackupJson()
                                    val result = GoogleDriveManager.uploadBackupToDrive(context, acc, backupJson)
                                    isDriveLoading = false
                                    if (result.isSuccess) {
                                        Toast.makeText(context, result.getOrDefault("Google Drive-এ ব্যাকআপ সেভ হয়েছে!"), Toast.LENGTH_LONG).show()
                                        val infoRes = GoogleDriveManager.getLastBackupInfo(context, acc)
                                        if (infoRes.isSuccess) {
                                            driveLastBackupTime = infoRes.getOrNull()
                                        }
                                    } else {
                                        Toast.makeText(context, "ব্যাকআপ ব্যর্থ: ${result.exceptionOrNull()?.localizedMessage}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            enabled = !isDriveLoading,
                            modifier = Modifier.weight(1f).testTag("btn_drive_backup"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DeepBluePrimary)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudUpload,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Drive-এ ব্যাকআপ", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                val acc = googleAccount ?: return@Button
                                isDriveLoading = true
                                coroutineScope.launch {
                                    val result = GoogleDriveManager.downloadBackupFromDrive(context, acc)
                                    isDriveLoading = false
                                    if (result.isSuccess) {
                                        val content = result.getOrThrow()
                                        val validation = viewModel.validateBackupJson(content)
                                        if (validation.isSuccess) {
                                            val records = validation.getOrThrow()
                                            pendingDriveRestoreContent = content
                                            pendingDriveRecordCount = records.size
                                            showConfirmDriveRestoreDialog = true
                                        } else {
                                            val err = validation.exceptionOrNull()?.localizedMessage ?: "অবৈধ ব্যাকআপ ডাটা"
                                            Toast.makeText(context, "ব্যাকআপ ফাইল ত্রুটিযুক্ত: $err", Toast.LENGTH_LONG).show()
                                        }
                                    } else {
                                        Toast.makeText(context, "ডাউনলোড ব্যর্থ: ${result.exceptionOrNull()?.localizedMessage}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            enabled = !isDriveLoading,
                            modifier = Modifier.weight(1f).testTag("btn_drive_restore"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudDownload,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Drive থেকে রিস্টোর", color = MaterialTheme.colorScheme.onSecondaryContainer, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Data Backup & Management Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "ডাটা ব্যাকআপ ও অফলাইন তথ্য সংরক্ষণ",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "অ্যাপের সকল তথ্য আপনার ফোনে নিরাপদভাবে সংরক্ষিত থাকে। ডাটা ব্যাকআপ ব্যাকআপ কপি করে রাখুন।",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                            createDocumentLauncher.launch("rider_backup_$timeStamp.json")
                        },
                        modifier = Modifier.weight(1f).testTag("btn_export_backup"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Icon(imageVector = Icons.Default.Backup, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ব্যাকআপ এক্সপোর্ট", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            openDocumentLauncher.launch(arrayOf("application/json", "text/*", "*/*"))
                        },
                        modifier = Modifier.weight(1f).testTag("btn_import_restore"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ব্যাকআপ রিস্টোর", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                    }
                }

                OutlinedButton(
                    onClick = { showClearDataDialog = true },
                    modifier = Modifier.fillMaxWidth().testTag("btn_clear_all_data"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("সকল তথ্য মুছে ফেলুন (Clear All)", color = ErrorRed)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }

    // Export Backup Dialog
    if (showBackupDialog) {
        AlertDialog(
            onDismissRequest = { showBackupDialog = false },
            title = { Text("ডাটা ব্যাকআপ কোড (JSON)") },
            text = {
                Column {
                    Text("নিচের কোডটি কপি করে অন্য ডিভাইসে বা নিরাপদ স্থানে রেখে দিন:", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = backupJsonText,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth().height(150.dp),
                        maxLines = 10
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        clipboardManager.setText(AnnotatedString(backupJsonText))
                        Toast.makeText(context, "কোড ক্লিপবোর্ডে কপি করা হয়েছে!", Toast.LENGTH_SHORT).show()
                        showBackupDialog = false
                    }
                ) {
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("কপি করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBackupDialog = false }) {
                    Text("বন্ধ করুন")
                }
            }
        )
    }

    // Restore Backup Dialog
    if (showRestoreDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = { Text("ব্যাকআপ ডাটা রিস্টোর করুন") },
            text = {
                Column {
                    Text("আপনার আগের সেভ করা ব্যাকআপ কোডটি এখানে পেস্ট করুন:", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = importJsonText,
                        onValueChange = { importJsonText = it },
                        placeholder = { Text("JSON কোড পেস্ট করুন...") },
                        modifier = Modifier.fillMaxWidth().height(150.dp),
                        maxLines = 10
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (importJsonText.isNotBlank()) {
                            val validation = viewModel.validateBackupJson(importJsonText)
                            if (validation.isSuccess) {
                                val records = validation.getOrThrow()
                                pendingRestoreContent = importJsonText
                                pendingRestoreRecordCount = records.size
                                importJsonText = ""
                                showRestoreDialog = false
                                showConfirmRestoreDialog = true
                            } else {
                                val errMsg = validation.exceptionOrNull()?.message ?: "অবৈধ ব্যাকআপ ফাইল"
                                Toast.makeText(context, "রিস্টোর ব্যর্থ: $errMsg", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                ) {
                    Text("যাচাই ও রিস্টোর")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }

    // Confirm Restore Dialog
    if (showConfirmRestoreDialog && pendingRestoreContent != null) {
        AlertDialog(
            onDismissRequest = {
                showConfirmRestoreDialog = false
                pendingRestoreContent = null
            },
            title = { Text("ডাটা রিস্টোর নিশ্চিত করুন") },
            text = {
                Text("আপনার ব্যাকআপ ফাইলে $pendingRestoreRecordCount টি ডাটা রেকর্ড পাওয়া গেছে। এটি রিস্টোর করলে বর্তমান সমস্ত তথ্য মুছে যাবে এবং ব্যাকআপ ডাটা যুক্ত হবে। আপনি কি নিশ্চিত?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        val jsonToRestore = pendingRestoreContent ?: ""
                        showConfirmRestoreDialog = false
                        pendingRestoreContent = null
                        viewModel.restoreBackupJson(
                            jsonString = jsonToRestore,
                            onSuccess = { count ->
                                Toast.makeText(context, "$count টি রেকর্ড সফলভাবে রিস্টোর করা হয়েছে!", Toast.LENGTH_LONG).show()
                            },
                            onError = { err ->
                                Toast.makeText(context, "রিস্টোর ব্যর্থ: $err", Toast.LENGTH_LONG).show()
                            }
                        )
                    }
                ) {
                    Text("হ্যাঁ, রিস্টোর করুন")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showConfirmRestoreDialog = false
                        pendingRestoreContent = null
                    }
                ) {
                    Text("বাতিল")
                }
            }
        )
    }

    // Confirm Drive Restore Dialog
    if (showConfirmDriveRestoreDialog && pendingDriveRestoreContent != null) {
        AlertDialog(
            onDismissRequest = {
                showConfirmDriveRestoreDialog = false
                pendingDriveRestoreContent = null
            },
            title = { Text("Google Drive থেকে রিস্টোর নিশ্চিত করুন") },
            text = {
                Text("Google Drive-এর ব্যাকআপ ফাইলে $pendingDriveRecordCount টি ডাটা রেকর্ড পাওয়া গেছে। এটি রিস্টোর করলে বর্তমান সমস্ত লোকাল ডাটা প্রতিস্থাপিত হবে। আপনি কি রিস্টোর করতে চান?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        val jsonToRestore = pendingDriveRestoreContent ?: ""
                        showConfirmDriveRestoreDialog = false
                        pendingDriveRestoreContent = null
                        viewModel.restoreBackupJson(
                            jsonString = jsonToRestore,
                            onSuccess = { count ->
                                Toast.makeText(context, "Google Drive থেকে $count টি রেকর্ড সফলভাবে রিস্টোর করা হয়েছে!", Toast.LENGTH_LONG).show()
                            },
                            onError = { err ->
                                Toast.makeText(context, "রিস্টোর ব্যর্থ: $err", Toast.LENGTH_LONG).show()
                            }
                        )
                    }
                ) {
                    Text("হ্যাঁ, রিস্টোর করুন")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showConfirmDriveRestoreDialog = false
                        pendingDriveRestoreContent = null
                    }
                ) {
                    Text("বাতিল")
                }
            }
        )
    }

    // Clear All Data Confirmation
    if (showClearDataDialog) {
        AlertDialog(
            onDismissRequest = { showClearDataDialog = false },
            title = { Text("সকল ডাটা মুছে ফেলবেন?") },
            text = { Text("আপনার সেভ করা সমস্ত রাইডার হিস্ট্রি স্থায়ীভাবে মুছে যাবে। আপনি কি নিশ্চিত?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearAllData()
                        showClearDataDialog = false
                    }
                ) {
                    Text("হ্যাঁ, সব মুছুন", color = ErrorRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDataDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }
}
