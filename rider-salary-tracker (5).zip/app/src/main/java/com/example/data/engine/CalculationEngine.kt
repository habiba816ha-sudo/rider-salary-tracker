package com.example.data.engine

import com.example.data.model.DailyRecord
import com.example.data.model.MonthlySummary
import com.example.data.model.RiderType
import java.util.Calendar
import java.util.Locale
import kotlin.math.floor

object CalculationEngine {

    fun calculateTarget(delivery: Int, returnCount: Int, holdCount: Int): Int {
        val safeDelivery = delivery.coerceAtLeast(0)
        val safeReturn = returnCount.coerceAtLeast(0)
        val safeHold = holdCount.coerceAtLeast(0)
        return safeDelivery + safeReturn + safeHold
    }

    fun calculatePercentage(delivery: Int, target: Int): Double {
        val safeDelivery = delivery.coerceAtLeast(0)
        val safeTarget = target.coerceAtLeast(0)
        if (safeTarget == 0) return 0.0
        return (safeDelivery.toDouble() / safeTarget) * 100.0
    }

    fun calculateCommissionRate(delivery: Int, riderType: RiderType): Int {
        val safeDelivery = delivery.coerceAtLeast(0)
        return when (riderType) {
            RiderType.INSIDE -> {
                if (safeDelivery <= 19) {
                    23
                } else {
                    25 + (floor((safeDelivery - 20).toDouble() / 5.0).toInt() * 2)
                }
            }
            RiderType.OUTSIDE -> {
                if (safeDelivery <= 19) {
                    30
                } else {
                    32 + (floor((safeDelivery - 20).toDouble() / 5.0).toInt() * 2)
                }
            }
        }
    }

    fun calculateEligibleIncome(delivery: Int, commissionRate: Int): Int {
        val safeDelivery = delivery.coerceAtLeast(0)
        val safeRate = commissionRate.coerceAtLeast(0)
        return safeDelivery * safeRate
    }

    fun calculateOilBill(delivery: Int, riderType: RiderType): Int {
        val safeDelivery = delivery.coerceAtLeast(0)
        if (safeDelivery == 0) return 0
        return when (riderType) {
            RiderType.INSIDE -> 100
            RiderType.OUTSIDE -> 200
        }
    }

    fun calculateDailyTotal(eligibleIncome: Int, oilBill: Int): Int {
        val safeIncome = eligibleIncome.coerceAtLeast(0)
        val safeOil = oilBill.coerceAtLeast(0)
        return safeIncome + safeOil
    }

    /**
     * Calculates the start and end dates (yyyy-MM-dd) for the 26th–25th salary cycle.
     * For example, month = 8, year = 2026:
     * Start Date = 2026-07-26
     * End Date = 2026-08-25
     */
    fun getSalaryPeriodDateRange(year: Int, month: Int): Pair<String, String> {
        val prevYear = if (month == 1) year - 1 else year
        val prevMonth = if (month == 1) 12 else month - 1
        val startStr = String.format(Locale.US, "%04d-%02d-26", prevYear, prevMonth)
        val endStr = String.format(Locale.US, "%04d-%02d-25", year, month)
        return Pair(startStr, endStr)
    }

    fun getSalaryMonthNameEn(month: Int): String {
        return when (month) {
            1 -> "January"
            2 -> "February"
            3 -> "March"
            4 -> "April"
            5 -> "May"
            6 -> "June"
            7 -> "July"
            8 -> "August"
            9 -> "September"
            10 -> "October"
            11 -> "November"
            12 -> "December"
            else -> ""
        }
    }

    fun getSalaryMonthNameBn(month: Int): String {
        return when (month) {
            1 -> "জানুয়ারি"
            2 -> "ফেব্রুয়ারি"
            3 -> "মার্চ"
            4 -> "এপ্রিল"
            5 -> "মে"
            6 -> "জুন"
            7 -> "জুলাই"
            8 -> "আগস্ট"
            9 -> "সেপ্টেম্বর"
            10 -> "অক্টোবর"
            11 -> "নভেম্বর"
            12 -> "ডিসেম্বর"
            else -> ""
        }
    }

    /**
     * Formats the human-readable salary calculation period, e.g.:
     * "26 July 2026 – 25 August 2026"
     */
    fun getSalaryPeriodDisplayString(year: Int, month: Int): String {
        val prevYear = if (month == 1) year - 1 else year
        val prevMonth = if (month == 1) 12 else month - 1
        val prevMonthName = getSalaryMonthNameEn(prevMonth)
        val currMonthName = getSalaryMonthNameEn(month)
        return "26 $prevMonthName $prevYear – 25 $currMonthName $year"
    }

    /**
     * Determines which salary month (year, month 1..12) currently applies for today.
     * If day >= 26, it belongs to the next month's salary cycle.
     */
    fun getCurrentSalaryMonth(): Pair<Int, Int> {
        val cal = Calendar.getInstance()
        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH) + 1 // 1-12
        val d = cal.get(Calendar.DAY_OF_MONTH)
        return if (d >= 26) {
            if (m == 12) Pair(y + 1, 1) else Pair(y, m + 1)
        } else {
            Pair(y, m)
        }
    }

    fun calculateMonthlySummary(
        year: Int,
        month: Int,
        records: List<DailyRecord>
    ): MonthlySummary {
        val (startDate, endDate) = getSalaryPeriodDateRange(year, month)
        val periodDisplay = getSalaryPeriodDisplayString(year, month)

        // Filter records strictly within 26th of previous month to 25th of current month
        val cycleRecords = records
            .filter { it.dateString.isNotBlank() && it.dateString >= startDate && it.dateString <= endDate }
            .distinctBy { it.dateString }

        val totalRecords = cycleRecords.size
        val workingDays = cycleRecords.count { it.delivery > 0 }
        
        val totalDelivery = cycleRecords.sumOf { it.delivery }
        val totalReturn = cycleRecords.sumOf { it.returnCount }
        val totalHold = cycleRecords.sumOf { it.holdCount }
        val totalTarget = cycleRecords.sumOf { it.target }

        val avgDelivery = if (workingDays > 0) totalDelivery.toDouble() / workingDays else 0.0
        val avgReturn = if (workingDays > 0) totalReturn.toDouble() / workingDays else 0.0
        val avgHold = if (workingDays > 0) totalHold.toDouble() / workingDays else 0.0

        val overallPercentage = if (totalTarget > 0) (totalDelivery.toDouble() / totalTarget) * 100.0 else 0.0

        val totalEligibleIncome = cycleRecords.sumOf { it.eligibleIncome }
        val totalOilBill = cycleRecords.sumOf { it.oilBill }
        val expectedMonthlyPayment = totalEligibleIncome + totalOilBill

        return MonthlySummary(
            year = year,
            month = month,
            calculationPeriod = periodDisplay,
            totalRecords = totalRecords,
            workingDays = workingDays,
            totalDelivery = totalDelivery,
            totalReturn = totalReturn,
            totalHold = totalHold,
            totalTarget = totalTarget,
            avgDelivery = avgDelivery,
            avgReturn = avgReturn,
            avgHold = avgHold,
            overallPercentage = overallPercentage,
            totalEligibleIncome = totalEligibleIncome,
            totalOilBill = totalOilBill,
            expectedMonthlyPayment = expectedMonthlyPayment
        )
    }
}
