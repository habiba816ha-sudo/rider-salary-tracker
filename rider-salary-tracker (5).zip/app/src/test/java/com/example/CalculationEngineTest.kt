package com.example.data.engine

import com.example.data.model.DailyRecord
import com.example.data.model.RiderType
import org.junit.Assert.assertEquals
import org.junit.Test

class CalculationEngineTest {

    @Test
    fun testInsideRiderCase1_Delivery19_Return3_Hold3() {
        val delivery = 19
        val returnCount = 3
        val holdCount = 3
        val riderType = RiderType.INSIDE

        val target = CalculationEngine.calculateTarget(delivery, returnCount, holdCount)
        val percentage = CalculationEngine.calculatePercentage(delivery, target)
        val rate = CalculationEngine.calculateCommissionRate(delivery, riderType)
        val income = CalculationEngine.calculateEligibleIncome(delivery, rate)
        val oilBill = CalculationEngine.calculateOilBill(delivery, riderType)
        val dailyTotal = CalculationEngine.calculateDailyTotal(income, oilBill)

        assertEquals(25, target)
        assertEquals(76.0, percentage, 0.01)
        assertEquals(23, rate)
        assertEquals(437, income)
        assertEquals(100, oilBill)
        assertEquals(537, dailyTotal)
    }

    @Test
    fun testInsideRiderCase2_Delivery20_Return0_Hold0() {
        val delivery = 20
        val returnCount = 0
        val holdCount = 0
        val riderType = RiderType.INSIDE

        val target = CalculationEngine.calculateTarget(delivery, returnCount, holdCount)
        val percentage = CalculationEngine.calculatePercentage(delivery, target)
        val rate = CalculationEngine.calculateCommissionRate(delivery, riderType)
        val income = CalculationEngine.calculateEligibleIncome(delivery, rate)
        val oilBill = CalculationEngine.calculateOilBill(delivery, riderType)
        val dailyTotal = CalculationEngine.calculateDailyTotal(income, oilBill)

        assertEquals(20, target)
        assertEquals(100.0, percentage, 0.01)
        assertEquals(25, rate)
        assertEquals(500, income)
        assertEquals(100, oilBill)
        assertEquals(600, dailyTotal)
    }

    @Test
    fun testOutsideRiderCase1_Delivery19_Return3_Hold3() {
        val delivery = 19
        val returnCount = 3
        val holdCount = 3
        val riderType = RiderType.OUTSIDE

        val target = CalculationEngine.calculateTarget(delivery, returnCount, holdCount)
        val percentage = CalculationEngine.calculatePercentage(delivery, target)
        val rate = CalculationEngine.calculateCommissionRate(delivery, riderType)
        val income = CalculationEngine.calculateEligibleIncome(delivery, rate)
        val oilBill = CalculationEngine.calculateOilBill(delivery, riderType)
        val dailyTotal = CalculationEngine.calculateDailyTotal(income, oilBill)

        assertEquals(25, target)
        assertEquals(76.0, percentage, 0.01)
        assertEquals(30, rate)
        assertEquals(570, income)
        assertEquals(200, oilBill)
        assertEquals(770, dailyTotal)
    }

    @Test
    fun testOutsideRiderCase2_Delivery20_Return0_Hold0() {
        val delivery = 20
        val returnCount = 0
        val holdCount = 0
        val riderType = RiderType.OUTSIDE

        val target = CalculationEngine.calculateTarget(delivery, returnCount, holdCount)
        val percentage = CalculationEngine.calculatePercentage(delivery, target)
        val rate = CalculationEngine.calculateCommissionRate(delivery, riderType)
        val income = CalculationEngine.calculateEligibleIncome(delivery, rate)
        val oilBill = CalculationEngine.calculateOilBill(delivery, riderType)
        val dailyTotal = CalculationEngine.calculateDailyTotal(income, oilBill)

        assertEquals(20, target)
        assertEquals(100.0, percentage, 0.01)
        assertEquals(32, rate)
        assertEquals(640, income)
        assertEquals(200, oilBill)
        assertEquals(840, dailyTotal)
    }

    @Test
    fun testZeroDelivery() {
        val delivery = 0
        val returnCount = 0
        val holdCount = 0
        val riderType = RiderType.INSIDE

        val target = CalculationEngine.calculateTarget(delivery, returnCount, holdCount)
        val percentage = CalculationEngine.calculatePercentage(delivery, target)
        val rate = CalculationEngine.calculateCommissionRate(delivery, riderType)
        val income = CalculationEngine.calculateEligibleIncome(delivery, rate)
        val oilBill = CalculationEngine.calculateOilBill(delivery, riderType)
        val dailyTotal = CalculationEngine.calculateDailyTotal(income, oilBill)

        assertEquals(0, target)
        assertEquals(0.0, percentage, 0.01)
        assertEquals(23, rate)
        assertEquals(0, income)
        assertEquals(0, oilBill)
        assertEquals(0, dailyTotal)
    }

    @Test
    fun testSalaryCycleDateRangeAndSummary() {
        val (startAug, endAug) = CalculationEngine.getSalaryPeriodDateRange(2026, 8)
        assertEquals("2026-07-26", startAug)
        assertEquals("2026-08-25", endAug)
        assertEquals("26 July 2026 – 25 August 2026", CalculationEngine.getSalaryPeriodDisplayString(2026, 8))

        val (startJan, endJan) = CalculationEngine.getSalaryPeriodDateRange(2027, 1)
        assertEquals("2026-12-26", startJan)
        assertEquals("2027-01-25", endJan)
        assertEquals("26 December 2026 – 25 January 2027", CalculationEngine.getSalaryPeriodDisplayString(2027, 1))

        // Test Monthly Summary with sample records across boundary
        val records = listOf(
            DailyRecord(
                id = 1,
                dateString = "2026-07-25", // Outside Aug cycle (belongs to July cycle)
                year = 2026, month = 7, day = 25,
                riderType = "INSIDE", delivery = 10, returnCount = 0, holdCount = 0,
                target = 10, percentage = 100.0, commissionRate = 23, eligibleIncome = 230,
                oilBill = 100, dailyTotal = 330
            ),
            DailyRecord(
                id = 2,
                dateString = "2026-07-26", // Inside Aug cycle start
                year = 2026, month = 7, day = 26,
                riderType = "INSIDE", delivery = 20, returnCount = 0, holdCount = 0,
                target = 20, percentage = 100.0, commissionRate = 25, eligibleIncome = 500,
                oilBill = 100, dailyTotal = 600
            ),
            DailyRecord(
                id = 3,
                dateString = "2026-08-25", // Inside Aug cycle end
                year = 2026, month = 8, day = 25,
                riderType = "INSIDE", delivery = 20, returnCount = 0, holdCount = 0,
                target = 20, percentage = 100.0, commissionRate = 25, eligibleIncome = 500,
                oilBill = 100, dailyTotal = 600
            ),
            DailyRecord(
                id = 4,
                dateString = "2026-08-26", // Outside Aug cycle (belongs to Sep cycle)
                year = 2026, month = 8, day = 26,
                riderType = "INSIDE", delivery = 30, returnCount = 0, holdCount = 0,
                target = 30, percentage = 100.0, commissionRate = 29, eligibleIncome = 870,
                oilBill = 100, dailyTotal = 970
            )
        )

        val summaryAug = CalculationEngine.calculateMonthlySummary(2026, 8, records)
        assertEquals(2, summaryAug.totalRecords)
        assertEquals(2, summaryAug.workingDays)
        assertEquals(40, summaryAug.totalDelivery)
        assertEquals(1000, summaryAug.totalEligibleIncome)
        assertEquals(200, summaryAug.totalOilBill)
        assertEquals(1200, summaryAug.expectedMonthlyPayment)
        assertEquals("26 July 2026 – 25 August 2026", summaryAug.calculationPeriod)
    }
}
